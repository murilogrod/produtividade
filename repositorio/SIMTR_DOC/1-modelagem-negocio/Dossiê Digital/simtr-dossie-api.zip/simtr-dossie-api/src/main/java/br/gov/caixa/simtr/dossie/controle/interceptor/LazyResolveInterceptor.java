package br.gov.caixa.simtr.dossie.controle.interceptor;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class LazyResolveInterceptor {

	private static final Logger LOGGER = Logger.getLogger(LazyResolveInterceptor.class.getName());

	private static final Map<Class<?>, Field[]> CLASSES_ENTIDADES = new HashMap<>();

	@AroundInvoke
	public Object intercept(InvocationContext context) throws Exception {
		LOGGER.log(Level.INFO, "LazyResolveInterceptor - Logging BEFORE calling method :{0}",
				context.getMethod().getName());
		Object result = context.proceed();
		if (context.getMethod().getReturnType() == java.util.List.class) {
			eleminteAllProxysToList((List<?>) result);
		} else if ((result != null) && (isEntity(result.getClass()))) {
			eleminteAllProxysToObject(result);
		}
		return result;
	}

	private void eleminteAllProxysToList(List<?> listOfObjects) {

		if ((listOfObjects != null) && (!listOfObjects.isEmpty())) {
			listOfObjects.forEach((objectOfList) -> {
				eleminteAllProxysToObject(objectOfList);
			});
		}
	}

	private void eleminteAllProxysToObject(Object entity) {
		Field[] fields = fieldsOfEntity(entity);
		if (fields != null) {
			for (Field field : fields) {
				try {
					entity.getClass().getDeclaredField(field.getName()).setAccessible(true);
					if (field.get(entity) != null) {
						String nameCanonical = field.get(entity).getClass().getCanonicalName();
						if (nameCanonical
								.equalsIgnoreCase("org.eclipse.persistence.internal.indirection.jdk8.IndirectList")) {
							Object proxy = field.get(entity);
							Field[] fieldsProxy = proxy.getClass().getDeclaredFields();
							for (Field fieldProxy : fieldsProxy) {
								LOGGER.info(fieldProxy.getName());
							}
							field.set(entity, null);
						} else if (nameCanonical.equalsIgnoreCase("org.hibernate.collection.internal.PersistentBag")) {
							Object proxy = field.get(entity);
							Field fieldProxy = proxy.getClass().getDeclaredField("bag");
							fieldProxy.setAccessible(true);
							if (fieldProxy.get(proxy) == null) {
								field.set(entity, null);
							}
						} else if (nameCanonical.equalsIgnoreCase("org.hibernate.collection.internal.PersistentSet")) {
							Object proxy = field.get(entity);
							Field fieldProxy = proxy.getClass().getDeclaredField("set");
							fieldProxy.setAccessible(true);
							if (fieldProxy.get(proxy) == null) {
								field.set(entity, null);
							}
						} else if (!nameCanonical.equalsIgnoreCase(field.getType().getCanonicalName())) {
							field.set(entity, null);
						} else if (isEntity(field.getType())) {
							eleminteAllProxysToObject(field.get(entity));
						}
					}
				} catch (IllegalAccessException | IllegalArgumentException | NoSuchFieldException
						| SecurityException e) {
					LOGGER.log(Level.SEVERE, e.getLocalizedMessage(), e);
				}
			}
		}

	}

	private Field[] fieldsOfEntity(Object object) {
		Field[] result = null;
		if (CLASSES_ENTIDADES.containsKey(object.getClass())) {
			result = CLASSES_ENTIDADES.get(object.getClass());
		} else if (isEntity(object.getClass())) {
			List<Field> fieldsList = new ArrayList<>();
			Field[] fieldsToClass = object.getClass().getDeclaredFields();
			for (Field fieldToClass : fieldsToClass) {
				// if ((fieldToClass.getType() == java.util.List.class) ||
				// (isEntity(fieldToClass.getType()))) {
				if ((java.util.Collection.class.isAssignableFrom(fieldToClass.getType()))
						|| (isEntity(fieldToClass.getType()))) {
					fieldToClass.setAccessible(true);
					fieldsList.add(fieldToClass);
				}
			}
			Field[] fields = new Field[fieldsList.size()];
			fields = fieldsList.toArray(fields);
			CLASSES_ENTIDADES.put(object.getClass(), fields);
			result = fields;

		}

		return result;
	}

	private boolean isEntity(Class<?> classOfObjects) {
		if (CLASSES_ENTIDADES.containsKey(classOfObjects)) {
			return true;
		}
		Annotation[] annotations = classOfObjects.getAnnotations();
		if ((annotations == null) || (annotations.length == 0)) {
			return false;
		}
		for (Annotation annotation : annotations) {
			if (annotation.annotationType() == javax.persistence.Entity.class) {
				return true;
			}
		}
		return false;
	}
}
