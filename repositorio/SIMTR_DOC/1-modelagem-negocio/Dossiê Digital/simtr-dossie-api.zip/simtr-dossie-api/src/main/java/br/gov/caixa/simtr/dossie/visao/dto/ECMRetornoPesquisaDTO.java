package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "RetornoPesquisa")
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMRetornoPesquisaDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private Integer codigoRetorno;
	private String mensagem;
	private Integer quantidade;
	@XmlElement(name = "dadosDocumentoLocalizado")
	private List<ECMDocumentoLocalizadoDTO> documentosLocalizados;

	public Integer getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(Integer codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public List<ECMDocumentoLocalizadoDTO> getDocumentosLocalizados() {
		return documentosLocalizados;
	}

	public void setDocumentosLocalizados(List<ECMDocumentoLocalizadoDTO> documentosLocalizados) {
		this.documentosLocalizados = documentosLocalizados;
	}

}
