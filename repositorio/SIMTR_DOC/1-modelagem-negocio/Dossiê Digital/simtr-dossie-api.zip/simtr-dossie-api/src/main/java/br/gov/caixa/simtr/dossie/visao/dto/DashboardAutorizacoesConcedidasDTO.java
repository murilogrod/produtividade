package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "dashboard")
@XmlAccessorType(XmlAccessType.FIELD)
public class DashboardAutorizacoesConcedidasDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "produto")
	private String produto;
	@XmlElement(name = "autorizacoes")
	private List<DashboardResumoAutorizacaoDTO> autorizacoesEfetuadas;

	public DashboardAutorizacoesConcedidasDTO() {
		super();
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public List<DashboardResumoAutorizacaoDTO> getAutorizacoesEfetuadas() {
		return autorizacoesEfetuadas;
	}

	public void setAutorizacoesEfetuadas(List<DashboardResumoAutorizacaoDTO> autorizacoesEfetuadas) {
		this.autorizacoesEfetuadas = autorizacoesEfetuadas;
	}

}
