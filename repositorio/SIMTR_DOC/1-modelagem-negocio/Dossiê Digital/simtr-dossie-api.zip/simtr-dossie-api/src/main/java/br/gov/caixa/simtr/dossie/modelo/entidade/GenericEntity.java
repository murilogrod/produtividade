package br.gov.caixa.simtr.dossie.modelo.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Version;

import io.swagger.annotations.ApiModelProperty;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class GenericEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Campo de controle das versões do registro para viabilizar a concorrencia otimista", required = true)
	private Integer versao;

	@Version
	@Column(name = "nu_versao")
	public Integer getVersao() {
		return versao;
	}

	public void setVersao(Integer versao) {
		this.versao = versao;
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}
}
