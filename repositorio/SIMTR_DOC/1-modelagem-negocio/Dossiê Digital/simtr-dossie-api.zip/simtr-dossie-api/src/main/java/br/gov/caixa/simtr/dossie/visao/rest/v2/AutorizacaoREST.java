package br.gov.caixa.simtr.dossie.visao.rest.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import br.gov.caixa.simtr.dossie.controle.service.AutorizacaoService;
import br.gov.caixa.simtr.dossie.controle.service.ComposicaoDocumentalService;
import br.gov.caixa.simtr.dossie.controle.service.NivelDocumentalService;
import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;
import br.gov.caixa.simtr.dossie.util.Constantes;
import br.gov.caixa.simtr.dossie.visao.dto.AutorizacaoMultiplaRequestBodyDTO;
import br.gov.caixa.simtr.dossie.visao.dto.AutorizacaoRetornoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMAtributosDocumentoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDadosPessoaFisicaDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDadosPessoaJuridicaDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDadosRequisicaoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDestinoDocumentoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDocumentoLocalizadoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMPesquisaBodyDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMRespostaDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMRetornoPesquisaDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMTransacaoBodyDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMTransacaoDocumentoBodyDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ProdutoDTO;
import br.gov.caixa.simtr.dossie.visao.enumerator.AcaoECMEnum;
import br.gov.caixa.simtr.dossie.visao.rest.JaxRsActivator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Classe responsável por prover os recursos referentes a empresa.
 *
 * @author c090347
 * @see JaxRsActivator
 * @since 1.0
 * @version 1.0.0
 */
@Api(value = "Autorização")
@Path("/v2/autorizacao")
@RequestScoped
// @SecurityDomain("keycloak") --> CONFIGURAÇÃO ESPECIFICA PARA O KEYCLOAK
// @PermitAll --> CONFIGURAÇÃO ESPECIFICA DE SEGURANÇA
public class AutorizacaoREST {

	@Inject
	AutorizacaoService autorizacaoService;
	@Inject
	ComposicaoDocumentalService composicaoDocumentalService;
	@Inject
	NivelDocumentalService nivelDocumentalService;

	@Inject
	Logger log;

	@POST
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	// @RolesAllowed({ "GERENTE", "ANALISTA" }) --> CONFIGURAÇÃO ESPECIFICA DE
	// SEGURANÇA
	@ApiResponses({@ApiResponse(code = 200, message = "Autorização Concedida", response = AutorizacaoRetornoDTO.class)})
	public Response getAutorizacao(AutorizacaoMultiplaRequestBodyDTO autorizacaoMultiplaRequestBodyDTO,
			@QueryParam("token") String token) {
		try {
			ResponseBuilder response =  Response.status(Status.OK); 

			Long cpfCnpj = Long.valueOf(autorizacaoMultiplaRequestBodyDTO.getCpfCnpj());

			List<ECMDocumentoLocalizadoDTO> documentosLocalizadosECM = this.getDocumentosCliente(cpfCnpj,
					autorizacaoMultiplaRequestBodyDTO.getTipoPessoa(), token);

			this.nivelDocumentalService.atualizaNiveisDocumentaisCliente(cpfCnpj,
					autorizacaoMultiplaRequestBodyDTO.getTipoPessoa(), documentosLocalizadosECM);

			List<AutorizacaoRetornoDTO> autorizacoesRetornoDTO = new ArrayList<>();
			List<ProdutoDTO> produtos = autorizacaoMultiplaRequestBodyDTO.getProdutos();
			for (ProdutoDTO produtoDTO : produtos) {

				AutorizacaoRetornoDTO autorizacaoRetornoDTO = this.autorizacaoService.requestAutorizacao(
						autorizacaoMultiplaRequestBodyDTO.getCpfCnpj(),
						autorizacaoMultiplaRequestBodyDTO.getTipoPessoa(), produtoDTO.getOperacao(),
						produtoDTO.getModalidade(), documentosLocalizadosECM, "SIPAN");

				// Cria transação no ECM apenas se autorizado
				if (autorizacaoRetornoDTO.isAutorizado()) {
					try {
						this.createTransacaoECM(token, autorizacaoRetornoDTO);
					} catch (RuntimeException re) {
						response.status(Status.SERVICE_UNAVAILABLE);
						this.autorizacaoService.invalidaPorFalhaECM(autorizacaoRetornoDTO.getCodigoAutorizacao(),
								re.getMessage());
						autorizacaoRetornoDTO.setAutorizado(false);
						autorizacaoRetornoDTO.setCodigoAutorizacao(null);
						autorizacaoRetornoDTO.setObservacao("Falha de Comunicação com o sistema ECM");
					}
				}
				autorizacoesRetornoDTO.add(autorizacaoRetornoDTO);
			}
			response.entity(autorizacoesRetornoDTO);
			return response.build();

		} catch (RuntimeException re) {
			this.log.log(Level.SEVERE, ">>>>> AutorizacaoRest.getAutorizacao", re);
			AutorizacaoRetornoDTO autorizacaoRetornoDTO = new AutorizacaoRetornoDTO();
			autorizacaoRetornoDTO.setAutorizado(false);
			autorizacaoRetornoDTO.setCpfCnpj(autorizacaoMultiplaRequestBodyDTO.getCpfCnpj());
			// autorizacaoRetornoDTO.setModalidade(autorizacaoRequestBodyDTO.getModalidade());
			// autorizacaoRetornoDTO.setOperacao(autorizacaoRequestBodyDTO.getOperacao());
			autorizacaoRetornoDTO.setTipoPessoa(autorizacaoMultiplaRequestBodyDTO.getTipoPessoa());
			autorizacaoRetornoDTO.setObservacao("Falha ao gerar autorização: " + re.getLocalizedMessage());

			ResponseBuilder response = Response.status(Status.REQUEST_TIMEOUT).entity(autorizacaoRetornoDTO);

			return response.build();
		}
	}

	private void createTransacaoECM(String token, AutorizacaoRetornoDTO autorizacaoRetornoDTO) {

		ECMDadosRequisicaoDTO dadosRequisicaoTransacao = new ECMDadosRequisicaoDTO();
		dadosRequisicaoTransacao.setTipoRequisicao(AcaoECMEnum.CRIA_TRANSACAO_CLIENTE.toString());
		dadosRequisicaoTransacao.setLocalArmazenamento(Constantes.ECM_OBJECT_STORE);
		dadosRequisicaoTransacao.setIpUsuarioFinal("10.208.249.21");

		String cpfFormatado = ("00000000000".concat(String.valueOf(autorizacaoRetornoDTO.getCpfCnpj()))).substring(11);
		ECMDadosPessoaFisicaDTO dadosPF = new ECMDadosPessoaFisicaDTO();
		dadosPF.setCpf(String.valueOf(cpfFormatado + "_" + autorizacaoRetornoDTO.getCodigoAutorizacao()));
		// dadosPF.setDataNascimento("01011900");

		ECMTransacaoBodyDTO transacaoBody = new ECMTransacaoBodyDTO();
		transacaoBody.setDadosRequisicao(dadosRequisicaoTransacao);
		transacaoBody.setTransacao(autorizacaoRetornoDTO.getNomeProduto());
		transacaoBody.setTipoCliente("PF");
		transacaoBody.setDadosPF(dadosPF);

		Client client = ClientBuilder.newClient();

		ECMRespostaDTO retornoTransacaoECM = client
				.target(Constantes.ECM_URL_BASE + AcaoECMEnum.CRIA_TRANSACAO_CLIENTE.getEndPoint())
				.request(MediaType.APPLICATION_XML).header("Authorization", token)
				.put(Entity.xml(transacaoBody), ECMRespostaDTO.class);

		// Caso gere erros no processamente (codigo 1 ou 2) procede o
		// cancelamento
		if (retornoTransacaoECM.getCodigoRetorno() > 0) {
			throw new RuntimeException(retornoTransacaoECM.getMensagem());
		}

		ECMDadosRequisicaoDTO dadosRequisicaoDocumento = new ECMDadosRequisicaoDTO();
		dadosRequisicaoDocumento.setTipoRequisicao(AcaoECMEnum.ANEXA_DOCUMENTOS_TRANSACAO.toString());
		dadosRequisicaoDocumento.setLocalArmazenamento(Constantes.ECM_OBJECT_STORE);
		dadosRequisicaoDocumento.setIpUsuarioFinal("10.208.249.21");

		List<ECMDocumentoLocalizadoDTO> documentosUtilizados = autorizacaoRetornoDTO.getDocumentosUtilizados();

		List<ECMDestinoDocumentoDTO> destinosDocumento = new ArrayList<>();
		for (ECMDocumentoLocalizadoDTO documentoUtilizado : documentosUtilizados) {
			ECMDestinoDocumentoDTO destinoDocumento = new ECMDestinoDocumentoDTO();
			destinoDocumento.setIdDocumento(documentoUtilizado.getAtributosDocumento().getId());
			destinoDocumento.setTransacao(autorizacaoRetornoDTO.getNomeProduto());
			destinoDocumento.setTipoCliente("PF");
			destinoDocumento.setDadosPF(dadosPF);

			destinosDocumento.add(destinoDocumento);
		}

		ECMTransacaoDocumentoBodyDTO transacaoDocumentoBody = new ECMTransacaoDocumentoBodyDTO();
		transacaoDocumentoBody.setDadosRequisicao(dadosRequisicaoDocumento);
		transacaoDocumentoBody.setDestinosDocumento(destinosDocumento);

		ECMRespostaDTO retornoDocumentosECM = client
				.target(Constantes.ECM_URL_BASE + AcaoECMEnum.ANEXA_DOCUMENTOS_TRANSACAO.getEndPoint())
				.request(MediaType.APPLICATION_XML).header("Authorization", token)
				.put(Entity.xml(transacaoDocumentoBody), ECMRespostaDTO.class);

		// Caso gere erros no processamente (codigo 1 ou 2) procede o
		// cancelamento
		if (retornoDocumentosECM.getCodigoRetorno() > 0) {
			throw new RuntimeException(retornoDocumentosECM.getMensagem());
		}

		this.autorizacaoService.updateInformeECM(autorizacaoRetornoDTO.getCodigoAutorizacao(),
				retornoTransacaoECM.getMensagem());
	}

	private List<ECMDocumentoLocalizadoDTO> getDocumentosCliente(Long cpfCnpj, TipoPessoaEnum tipoPessoaEnum,
			String token) {
		List<ECMDocumentoLocalizadoDTO> documentosIdentificados = new ArrayList<>();

		if (new Long(11122233300L).equals(cpfCnpj)) {
			ECMDocumentoLocalizadoDTO identidade = new ECMDocumentoLocalizadoDTO();
			identidade.setLink("https://enderecodeacessoaimagem.caixa/contexto-sistema/kjccsdcsfdkjdsf368217ge8832dd");
			ECMAtributosDocumentoDTO atributosIdentidade = new ECMAtributosDocumentoDTO();
			atributosIdentidade.setClasseDocumental("IDENTIDADE");
			atributosIdentidade.setFormato("PNG");
			atributosIdentidade.setId("dteyugiqd783243221");
			atributosIdentidade.setMimeType("image/png");
			atributosIdentidade.setNome("IDENTIDADE");

			identidade.setAtributosDocumento(atributosIdentidade);
			documentosIdentificados.add(identidade);

			ECMDocumentoLocalizadoDTO residencia = new ECMDocumentoLocalizadoDTO();
			identidade.setLink("https://enderecodeacessoaimagem.caixa/contexto-sistema/weduygd3227d237d6g72f42h34gj");
			ECMAtributosDocumentoDTO atributosResidencia = new ECMAtributosDocumentoDTO();
			atributosResidencia.setClasseDocumental("CONTA_DE_AGUA");
			atributosResidencia.setFormato("PNG");
			atributosResidencia.setId("wefkjhgf34fj2h34k");
			atributosResidencia.setMimeType("image/png");
			atributosResidencia.setNome("CONTA DE LUZ");

			residencia.setAtributosDocumento(atributosResidencia);
			documentosIdentificados.add(residencia);

			ECMDocumentoLocalizadoDTO renda = new ECMDocumentoLocalizadoDTO();
			identidade.setLink("https://enderecodeacessoaimagem.caixa/contexto-sistema/hjkjh45kcbdsx32137643vgcgf3");
			ECMAtributosDocumentoDTO atributosRenda = new ECMAtributosDocumentoDTO();
			atributosRenda.setClasseDocumental("CONTRACHEQUE");
			atributosRenda.setFormato("PNG");
			atributosRenda.setId("567rfds2376fd32");
			atributosRenda.setMimeType("image/png");
			atributosRenda.setNome("CONTRA CHEQUE");

			renda.setAtributosDocumento(atributosRenda);
			documentosIdentificados.add(renda);
		} else {

			ECMDadosRequisicaoDTO dadosRequisicao = new ECMDadosRequisicaoDTO();
			dadosRequisicao.setTipoRequisicao(AcaoECMEnum.LISTA_CONTEUDO_DOSSIE.toString());
			dadosRequisicao.setLocalArmazenamento(Constantes.ECM_OBJECT_STORE);
			dadosRequisicao.setIpUsuarioFinal("10.208.249.21");

			ECMPesquisaBodyDTO pesquisaDTO = new ECMPesquisaBodyDTO();
			if (TipoPessoaEnum.F.equals(tipoPessoaEnum)) {
				String cpfFormatado = ("00000000000".concat(String.valueOf(cpfCnpj)));
				cpfFormatado = cpfFormatado.substring(cpfFormatado.length() - 11);
				ECMDadosPessoaFisicaDTO dadosPF = new ECMDadosPessoaFisicaDTO();
				dadosPF.setCpf(String.valueOf(cpfFormatado));
				// dadosPF.setDataNascimento("01011900");

				pesquisaDTO.setDadosRequisicao(dadosRequisicao);
				pesquisaDTO.setTipoCliente("PF");
				pesquisaDTO.setDadosPF(dadosPF);
			} else {
				String cnpjFormatado = ("00000000000000".concat(String.valueOf(cpfCnpj)));
				cnpjFormatado = cnpjFormatado.substring(cnpjFormatado.length() - 14);

				ECMDadosPessoaJuridicaDTO dadosPJ = new ECMDadosPessoaJuridicaDTO();
				dadosPJ.setCnpj(String.valueOf(cnpjFormatado));

				pesquisaDTO.setDadosRequisicao(dadosRequisicao);
				pesquisaDTO.setTipoCliente("PJ");
				pesquisaDTO.setDadosPJ(dadosPJ);

			}

			Client client = ClientBuilder.newClient();

			ECMRetornoPesquisaDTO retornoPesquisaECM = client
					.target(Constantes.ECM_URL_BASE + AcaoECMEnum.LISTA_CONTEUDO_DOSSIE.getEndPoint())
					.request(MediaType.APPLICATION_XML).header("Authorization", token)
					.post(Entity.xml(pesquisaDTO), ECMRetornoPesquisaDTO.class);

			List<ECMDocumentoLocalizadoDTO> documentosECM = retornoPesquisaECM.getDocumentosLocalizados();
			if ((documentosECM != null) && (!documentosECM.isEmpty())) {
				documentosIdentificados.addAll(documentosECM);
			}

		}

		return documentosIdentificados;
	}

}
