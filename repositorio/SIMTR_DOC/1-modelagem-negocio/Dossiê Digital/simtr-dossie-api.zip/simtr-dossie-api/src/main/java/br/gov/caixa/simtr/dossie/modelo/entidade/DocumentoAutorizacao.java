package br.gov.caixa.simtr.dossie.modelo.entidade;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Objects;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb101_documento")
@XmlRootElement
public class DocumentoAutorizacao extends GenericEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "Identificador unico do documento vinculado a autorização concedida", required = true)
    private Long id;
    private Autorizacao autorizacao;
    private String codigoGED;

    // ************************************
    public DocumentoAutorizacao() {
        super();
    }

    @Id
    @Column(name = "nu_documento")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToOne(targetEntity = Autorizacao.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "nu_autorizacao", nullable = false)
    public Autorizacao getAutorizacao() {
        return autorizacao;
    }

    public void setAutorizacao(Autorizacao autorizacao) {
        this.autorizacao = autorizacao;
    }

    @Column(name = "co_documento_ged", length = 255, nullable = false)
    public String getCodigoGED() {
        return codigoGED;
    }

    public void setCodigoGED(String codigoGED) {
        this.codigoGED = codigoGED;
    }

    // ************************************
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DocumentoAutorizacao other = (DocumentoAutorizacao) obj;
        return Objects.equals(this.id, other.id);
    }
}
