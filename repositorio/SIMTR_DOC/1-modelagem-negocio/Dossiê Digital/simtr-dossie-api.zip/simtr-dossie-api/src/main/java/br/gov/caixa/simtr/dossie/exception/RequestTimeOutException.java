package br.gov.caixa.simtr.dossie.exception;

public class RequestTimeOutException extends RuntimeException {

    /**
     * CODIGO 408 - TIMEOUT
     */
    private static final long serialVersionUID = 1L;

    public RequestTimeOutException(String message) {
        super(message);
    }

}
