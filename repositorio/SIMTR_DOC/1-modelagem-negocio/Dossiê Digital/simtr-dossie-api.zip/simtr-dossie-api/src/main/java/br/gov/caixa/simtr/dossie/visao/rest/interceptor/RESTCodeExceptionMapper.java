package br.gov.caixa.simtr.dossie.visao.rest.interceptor;

import javax.persistence.NoResultException;
import javax.validation.ConstraintDeclarationException;
import javax.validation.GroupDefinitionException;
import javax.validation.ValidationException;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.NotAcceptableException;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Produces;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import br.gov.caixa.simtr.dossie.exception.ConflictException;
import br.gov.caixa.simtr.dossie.exception.RequestTimeOutException;
import br.gov.caixa.simtr.dossie.util.Messages;
import br.gov.caixa.simtr.dossie.visao.dto.ResourceError;

@Provider
public class RESTCodeExceptionMapper implements ExceptionMapper<Exception> {

	@Override
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response toResponse(Exception e) {
		ResourceError resourceError = new ResourceError();

		if (e.getCause() instanceof NoResultException) {
			/**
			 * NOT FOUND EXCEPTION
			 */
			// SETA O CODIGO DE ERRO PARA O PADRAO HTTP 404
			resourceError.setCode(Response.Status.NOT_FOUND.getStatusCode());
			// SETA A MENSAGEM PARA O USUARIO FINAL
			resourceError.setMessage(Messages.getString("MSG_DADO_NAO_ENCONTRADO"));
			// SETA A MENSAGEM DE ERRO PARA SER TRATADA PELA CAMADA WEB.
			resourceError.setDetail(e.getCause().toString());

			return Response.status(Response.Status.NOT_FOUND).entity(resourceError).type(MediaType.APPLICATION_JSON)
					.build();

		} else if (e instanceof BadRequestException) {
			/**
			 * CODIGO 400 - BAD REQUEST
			 */
			resourceError.setCode(Response.Status.BAD_REQUEST.getStatusCode());
			resourceError.setMessage(Messages.getString("MSG_BAD_REQUEST"));
			resourceError.setDetail(e.getCause().getMessage());

			return Response.status(Response.Status.BAD_REQUEST).entity(resourceError).type(MediaType.APPLICATION_JSON)
					.build();

		} else if (e.toString().equals("org.jboss.resteasy.spi.UnauthorizedException")) {
			/**
			 * CODIGO 401 - UNAUTHORIZED
			 */
			resourceError.setCode(Response.Status.UNAUTHORIZED.getStatusCode());
			resourceError.setMessage(Messages.getString("MSG_USUARIO_NAO_AUTORIZADO"));
			return Response.status(Response.Status.UNAUTHORIZED).entity(resourceError).type(MediaType.APPLICATION_JSON)
					.type(MediaType.APPLICATION_JSON).build();

		} else if (e instanceof NotFoundException) {
			/**
			 * CODIGO 404 - NOT FOUND - javax.ws.rs.NotFoundException
			 */
			resourceError.setCode(Response.Status.NOT_FOUND.getStatusCode());
			resourceError.setMessage(e.getMessage());
			return Response.status(Response.Status.NOT_FOUND).entity(resourceError).type(MediaType.APPLICATION_JSON)
					.build();

		} else if (e instanceof NotAcceptableException) {
			/**
			 * CODIGO 406 - NOT ACCEPTABLE
			 */
			resourceError.setCode(Response.Status.NOT_ACCEPTABLE.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.NOT_ACCEPTABLE).entity(resourceError)
					.type(MediaType.APPLICATION_JSON).build();

		} else if (e instanceof ValidationException) {
			/**
			 * VALIDATION EXCEPTION
			 */
			resourceError.setCode(Response.Status.NOT_ACCEPTABLE.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.NOT_ACCEPTABLE).entity(resourceError)
					.type(MediaType.APPLICATION_JSON).build();

		} else if (e instanceof GroupDefinitionException) {
			/**
			 * CODIGO 406 - NOT ACCEPTABLE
			 */
			resourceError.setCode(Response.Status.NOT_ACCEPTABLE.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.NOT_ACCEPTABLE).entity(resourceError)
					.type(MediaType.APPLICATION_JSON).build();

		} else if (e instanceof ConstraintDeclarationException) {
			/**
			 * VALIDATION EXCEPTION
			 */
			resourceError.setCode(Response.Status.NOT_ACCEPTABLE.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.NOT_ACCEPTABLE).entity(resourceError)
					.type(MediaType.APPLICATION_JSON).build();

		} else if (e instanceof RequestTimeOutException) {
			/**
			 * CODIGO 408 - REQUEST TIMEOUT
			 */

			resourceError.setCode(Response.Status.REQUEST_TIMEOUT.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.REQUEST_TIMEOUT).entity(resourceError)
					.type(MediaType.APPLICATION_JSON).build();

		} else if (e instanceof ConflictException) {
			/**
			 * CODIGO 409 - CONFLICT
			 */
			resourceError.setCode(Response.Status.CONFLICT.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.CONFLICT).entity(resourceError).type(MediaType.APPLICATION_JSON)
					.build();

		} else if (e instanceof ServiceUnavailableException) {

			/**
			 * CODIGO 503 - Service Unavailable
			 */
			resourceError.setCode(Response.Status.CONFLICT.getStatusCode());
			resourceError.setMessage(e.getCause().getMessage());
			return Response.status(Response.Status.CONFLICT).entity(resourceError).type(MediaType.APPLICATION_JSON)
					.build();

		} else {

			/**
			 * CODIGO 500 - Internal Server Error
			 *
			 * SERA USADO PARA AS EXCECOES NAO MAPEADAS
			 */
			resourceError.setCode(Response.Status.INTERNAL_SERVER_ERROR.getStatusCode());

			if (e.getMessage() == null) {

				resourceError.setMessage(e.toString());

			} else {

				resourceError.setMessage(e.getMessage());
			}

			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(resourceError).build();

		}

	}

}
