package br.gov.caixa.simtr.dossie.visao.rest.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import br.gov.caixa.simtr.dossie.controle.service.AutorizacaoService;
import br.gov.caixa.simtr.dossie.controle.service.ComposicaoDocumentalService;
import br.gov.caixa.simtr.dossie.controle.service.MQService;
import br.gov.caixa.simtr.dossie.controle.service.vo.HabilitadoProdutoVO;
import br.gov.caixa.simtr.dossie.visao.dto.DashboardAutorizacoesConcedidasDTO;
import br.gov.caixa.simtr.dossie.visao.dto.DashboardDTO;
import br.gov.caixa.simtr.dossie.visao.dto.DashboardProdutoHabilitadoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.DashboardResumoAutorizacaoDTO;
import br.gov.caixa.simtr.dossie.visao.rest.JaxRsActivator;
import io.swagger.annotations.Api;

/**
 * Classe responsável por prover os recursos referentes a empresa.
 *
 * @author c090347
 * @see JaxRsActivator
 * @since 1.0
 * @version 1.0.0
 */
@Api(value = "Dashboard")
@Path("/v1/dashboard")
@RequestScoped
// @SecurityDomain("keycloak") --> CONFIGURAÇÃO ESPECIFICA PARA O KEYCLOAK
// @PermitAll --> CONFIGURAÇÃO ESPECIFICA DE SEGURANÇA
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
public class DashboardREST {

	@Inject
	private AutorizacaoService autorizacaoService;
	@Inject
	private ComposicaoDocumentalService composicaoDocumentalService;
	@EJB
	private MQService mqService;

	@Inject
	Logger log;

	@GET
	@Path("/")
	public Response getDadosDashBoard() {
		try {
			DashboardDTO dashboardDTO = new DashboardDTO();

			// Clientes Habilitados - Rotina para levantar a quantidade de
			// clientes habilitados por produtos
			List<HabilitadoProdutoVO> habilitadosProdutos = this.composicaoDocumentalService.listHabilitadosByProduto();

			List<DashboardProdutoHabilitadoDTO> clientesHabilitados = new ArrayList<>();
			for (HabilitadoProdutoVO habilitadoProdutoVO : habilitadosProdutos) {
				DashboardProdutoHabilitadoDTO dashboardProdutoHabilitadoDTO = new DashboardProdutoHabilitadoDTO();
				dashboardProdutoHabilitadoDTO.setOperacao(habilitadoProdutoVO.getOperacao());
				dashboardProdutoHabilitadoDTO.setModalidade(habilitadoProdutoVO.getModalidade());
				dashboardProdutoHabilitadoDTO.setProduto(habilitadoProdutoVO.getProduto());
				dashboardProdutoHabilitadoDTO.setQuantidade(habilitadoProdutoVO.getQuantidade());

				clientesHabilitados.add(dashboardProdutoHabilitadoDTO);
			}

			dashboardDTO.setClientesHabilitados(clientesHabilitados);
			// FIM Clientes Habilitados

			// Autorizações Concedidas - Rotina para levantar a quantidade de
			// autorizações concedidas nos ultimos 12 meses
			Map<String, Map<String, Long>> resumoAutorizacoes = this.autorizacaoService
					.getQuantidadeAutorizacoesMensais();
			Set<String> produtos = resumoAutorizacoes.keySet();

			List<DashboardAutorizacoesConcedidasDTO> autorizacoesConcedidas = new ArrayList<>();
			for (String produto : produtos) {

				DashboardAutorizacoesConcedidasDTO autorizacoesConcedidasDTO = new DashboardAutorizacoesConcedidasDTO();
				autorizacoesConcedidasDTO.setProduto(produto);

				Map<String, Long> resumo = resumoAutorizacoes.get(produto);
				Set<String> datas = resumo.keySet();

				List<DashboardResumoAutorizacaoDTO> resumosAutorizacaoDTO = new ArrayList<>();
				for (String data : datas) {
					Long quantidade = resumo.get(data);
					DashboardResumoAutorizacaoDTO resumoAutorizacaoDTO = new DashboardResumoAutorizacaoDTO(data,
							quantidade);
					resumosAutorizacaoDTO.add(resumoAutorizacaoDTO);
				}
				autorizacoesConcedidasDTO.setAutorizacoesEfetuadas(resumosAutorizacaoDTO);

				autorizacoesConcedidas.add(autorizacoesConcedidasDTO);
			}

			dashboardDTO.setAutorizacoesConcedidas(autorizacoesConcedidas);
			// FIM Autorizações Concedidas

			ResponseBuilder response = Response.status(200).entity(dashboardDTO);

			return response.build();

		} catch (RuntimeException re) {
			this.log.log(Level.SEVERE, ">>>>> DashboardRest.getDadosDashboard", re);
			ResponseBuilder response = Response.status(Status.INTERNAL_SERVER_ERROR);

			return response.build();
		}
	}

	@GET
	@Path("/sipes")
	public Response consultaSIPES() {
		String resposta = this.mqService.sendMessage();

		ResponseBuilder response = Response.status(200).entity(resposta);

		return response.build();
	}

}
