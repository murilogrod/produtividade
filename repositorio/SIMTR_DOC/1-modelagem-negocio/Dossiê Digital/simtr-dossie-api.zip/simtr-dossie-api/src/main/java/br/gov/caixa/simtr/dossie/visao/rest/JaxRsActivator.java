package br.gov.caixa.simtr.dossie.visao.rest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import br.gov.caixa.simtr.dossie.visao.rest.interceptor.RESTCodeExceptionMapper;
import br.gov.caixa.simtr.dossie.visao.rest.interceptor.RESTConstrainViolationExceptionMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.Contact;
import io.swagger.annotations.Info;
import io.swagger.annotations.License;
import io.swagger.annotations.SwaggerDefinition;
import io.swagger.annotations.Tag;
import io.swagger.jaxrs.config.BeanConfig;
import io.swagger.jaxrs.listing.ApiListingResource;
import io.swagger.jaxrs.listing.SwaggerSerializers;

/**
 * A class extending {@link Application} and annotated with @ApplicationPath is
 * the Java EE 7 "no XML" approach to activating JAX-RS.
 *
 * <p>
 * Resources are served relative to the servlet path specified in the
 * {@link ApplicationPath} annotation.
 * </p>
 */
@Api
@ApplicationPath("/rest")
@SwaggerDefinition(info = @Info(description = "Lista de APIs construídas para o Dossiê Digital", version = "1.0.0.0", title = "API do Dossiê Digital", termsOfService = "http://www.caixa.gov.br/api/terms.html", contact = @Contact(name = "GEABR", email = "geabr09@caixa.gov.br", url = "http://dossiedigital.caixa/"), license = @License(name = "Apache 2.0", url = "http://www.apache.org/licenses/LICENSE-2.0")), consumes = {
		"application/json", "application/xml" }, produces = { "application/json", "application/xml" }, schemes = {
				SwaggerDefinition.Scheme.HTTP, SwaggerDefinition.Scheme.HTTPS }, tags = {
						@Tag(name = "Private", description = "Tag used to denote operations as private") })
public class JaxRsActivator extends Application {

	public JaxRsActivator() {
		BeanConfig conf = new BeanConfig();
		conf.setHost("localhost:8080");
		conf.setBasePath("/sidos-api/rest");
		conf.setResourcePackage("br.gov.caixa.sidos");
		conf.setScan(true);
	}

	@Override
	public Set<Class<?>> getClasses() {
		Set<Class<?>> resources = new HashSet<>();
		resources.add(ApiListingResource.class);
		resources.add(RESTCodeExceptionMapper.class);
		resources.add(RESTConstrainViolationExceptionMapper.class);
		resources.add(SwaggerSerializers.class);

		resources.add(br.gov.caixa.simtr.dossie.visao.rest.v1.AutorizacaoREST.class);
		resources.add(br.gov.caixa.simtr.dossie.visao.rest.v2.AutorizacaoREST.class);
		resources.add(br.gov.caixa.simtr.dossie.visao.rest.v1.DashboardREST.class);
		return resources;
	}

}
