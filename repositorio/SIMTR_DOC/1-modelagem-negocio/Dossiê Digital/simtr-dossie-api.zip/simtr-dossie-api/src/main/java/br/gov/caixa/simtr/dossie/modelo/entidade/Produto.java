package br.gov.caixa.simtr.dossie.modelo.entidade;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.persistence.Index;
import javax.persistence.ManyToMany;

@Entity
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb006_produto", indexes = {
    @Index(name = "ix_dostb006_01", unique = true, columnList = "no_produto")})
@XmlRootElement
public class Produto extends GenericEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "Identificador unico do produto", required = true)
    private Integer id;
    private Integer operacao;
    private Integer modalidade;
    private String nome;

    // ************************************
    private Set<ComposicaoDocumental> composicoesDocumentais;

    public Produto() {
        super();
        this.composicoesDocumentais = new HashSet<>();
    }

    @Id
    @Column(name = "nu_produto")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "nu_operacao", nullable = false)
    public Integer getOperacao() {
        return operacao;
    }

    public void setOperacao(Integer operacao) {
        this.operacao = operacao;
    }

    @Column(name = "nu_modalidade", nullable = false)
    public Integer getModalidade() {
        return modalidade;
    }

    public void setModalidade(Integer modalidade) {
        this.modalidade = modalidade;
    }

    @Column(name = "no_produto", nullable = false, length = 255)
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    // ************************************
    @ApiModelProperty(hidden = true)
    @ManyToMany(targetEntity = ComposicaoDocumental.class, mappedBy = "produtos", fetch = FetchType.LAZY)
    public Set<ComposicaoDocumental> getComposicoesDocumentais() {
        return composicoesDocumentais;
    }

    public void setComposicoesDocumentais(Set<ComposicaoDocumental> composicoesDocumentais) {
        this.composicoesDocumentais = composicoesDocumentais;
    }

    // ************************************
    public boolean addComposicoesDocumentais(ComposicaoDocumental... composicoesDocumentais) {
        return this.composicoesDocumentais.addAll(Arrays.asList(composicoesDocumentais));
    }

    public boolean removeComposicoesDocumentais(ComposicaoDocumental... composicoesDocumentais) {
        return this.composicoesDocumentais.removeAll(Arrays.asList(composicoesDocumentais));
    }

    // ************************************
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 89 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Produto other = (Produto) obj;
        return Objects.equals(this.id, other.id);
    }
}
