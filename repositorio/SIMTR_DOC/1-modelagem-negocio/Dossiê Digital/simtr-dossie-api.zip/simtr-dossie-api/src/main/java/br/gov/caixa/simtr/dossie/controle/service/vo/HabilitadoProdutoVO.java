package br.gov.caixa.simtr.dossie.controle.service.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlAccessorType(XmlAccessType.FIELD)
public class HabilitadoProdutoVO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "operacao")
	private Integer operacao;
	@XmlElement(name = "modalidade")
	private Integer modalidade;
	@XmlElement(name = "produto")
	private String produto;
	@XmlElement(name = "quantidade")
	private Long quantidade;

	public HabilitadoProdutoVO() {
		super();
	}

	public HabilitadoProdutoVO(Integer operacao, Integer modalidade, String produto, Long quantidade) {
		super();
		this.operacao = operacao;
		this.modalidade = modalidade;
		this.produto = produto;
		this.quantidade = quantidade;
	}

	public Integer getOperacao() {
		return operacao;
	}

	public void setOperacao(Integer operacao) {
		this.operacao = operacao;
	}

	public Integer getModalidade() {
		return modalidade;
	}

	public void setModalidade(Integer modalidade) {
		this.modalidade = modalidade;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public Long getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Long quantidade) {
		this.quantidade = quantidade;
	}

}
