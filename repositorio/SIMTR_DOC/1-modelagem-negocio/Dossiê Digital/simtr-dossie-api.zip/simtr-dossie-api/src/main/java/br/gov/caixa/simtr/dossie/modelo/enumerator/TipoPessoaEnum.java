package br.gov.caixa.simtr.dossie.modelo.enumerator;

public enum TipoPessoaEnum {

	/*
	 * F - Fisica | J - Juridica
	 */
	F, J;
}
