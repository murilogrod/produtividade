package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

@XmlAccessorType(XmlAccessType.FIELD)
public class ECMDadosRequisicaoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private String tipoRequisicao;
	private String localArmazenamento;
	private String ipUsuarioFinal;

	public String getTipoRequisicao() {
		return tipoRequisicao;
	}

	public void setTipoRequisicao(String tipoRequisicao) {
		this.tipoRequisicao = tipoRequisicao;
	}

	public String getLocalArmazenamento() {
		return localArmazenamento;
	}

	public void setLocalArmazenamento(String localArmazenamento) {
		this.localArmazenamento = localArmazenamento;
	}

	public String getIpUsuarioFinal() {
		return ipUsuarioFinal;
	}

	public void setIpUsuarioFinal(String ipUsuarioFinal) {
		this.ipUsuarioFinal = ipUsuarioFinal;
	}

}
