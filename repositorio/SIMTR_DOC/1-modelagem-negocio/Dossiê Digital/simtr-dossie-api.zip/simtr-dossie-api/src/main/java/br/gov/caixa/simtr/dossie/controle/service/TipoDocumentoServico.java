package br.gov.caixa.simtr.dossie.controle.service;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.gov.caixa.simtr.dossie.modelo.entidade.TipoDocumento;

@Stateless
public class TipoDocumentoServico extends AbstractService<TipoDocumento> {

	@Inject
	private EntityManager entityManager;

	@Inject
	private Logger logger;

	public List<TipoDocumento> getAll() {
		logger.info("***** Metodo TipoDocumentoServico.getAll executado *****");
		List<TipoDocumento> tipos = this.entityManager
				.createQuery("SELECT td FROM TipoDocumento td ", TipoDocumento.class).getResultList();
		this.entityManager.flush();
		return tipos;
	}

	public List<TipoDocumento> getTiposDocumentosByProduto(Integer codigoOperacao, Integer codigoModalidade) {
		logger.info("***** Metodo TipoDocumentoServico.getTiposDocumentosByProduto executado *****");

		List<TipoDocumento> tiposDocumento = new ArrayList<>();

		StringBuilder jpql = new StringBuilder();
		jpql.append("   SELECT DISTINCT td FROM TipoDocumento td ");
		jpql.append("   LEFT JOIN FETCH td.regrasDocumentais rd ");
		jpql.append("   LEFT JOIN FETCH rd.composicaoDocumental cd ");
		jpql.append("   LEFT JOIN FETCH cd.produtos p ");
		jpql.append("   WHERE p.operacao = :operacao ");
		jpql.append("   	AND p.modalidade = :modalidade ");

		TypedQuery<TipoDocumento> queryTipoDocumentosByRegras = this.entityManager.createQuery(jpql.toString(),
				TipoDocumento.class);
		queryTipoDocumentosByRegras.setParameter("operacao", codigoOperacao);
		queryTipoDocumentosByRegras.setParameter("modalidade", codigoModalidade);

		tiposDocumento = queryTipoDocumentosByRegras.getResultList();

		this.entityManager.clear();

		jpql = new StringBuilder();
		jpql.append("   SELECT DISTINCT td FROM TipoDocumento td ");
		jpql.append("   LEFT JOIN FETCH td.funcoesDocumentais fd ");
		jpql.append("   LEFT JOIN FETCH fd.regrasDocumentais rd ");
		jpql.append("   LEFT JOIN FETCH rd.composicaoDocumental cd ");
		jpql.append("   LEFT JOIN FETCH cd.produtos p ");
		jpql.append("   WHERE p.operacao = :operacao ");
		jpql.append("   	AND p.modalidade = :modalidade ");

		TypedQuery<TipoDocumento> queryTipoDocumentosByFuncao = this.entityManager.createQuery(jpql.toString(),
				TipoDocumento.class);
		queryTipoDocumentosByFuncao.setParameter("operacao", codigoOperacao);
		queryTipoDocumentosByFuncao.setParameter("modalidade", codigoModalidade);

		tiposDocumento.addAll(queryTipoDocumentosByFuncao.getResultList());

		this.entityManager.clear();

		return tiposDocumento;
	}

	@Override
	protected EntityManager getEntityManager() {
		return this.entityManager;
	}

}
