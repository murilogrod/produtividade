package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "dashboard")
@XmlAccessorType(XmlAccessType.FIELD)
public class DashboardDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	@XmlElementWrapper(name = "habilitacoes")
	@XmlElement(name = "clientes_habilitados")
	private List<DashboardProdutoHabilitadoDTO> clientesHabilitados;
	@XmlElementWrapper(name = "concessoes")
	@XmlElement(name = "autorizacoes_concedidas")
	private List<DashboardAutorizacoesConcedidasDTO> autorizacoesConcedidas;

	public DashboardDTO() {
		super();
	}

	public List<DashboardProdutoHabilitadoDTO> getClientesHabilitados() {
		return clientesHabilitados;
	}

	public void setClientesHabilitados(List<DashboardProdutoHabilitadoDTO> clientesHabilitados) {
		this.clientesHabilitados = clientesHabilitados;
	}

	public List<DashboardAutorizacoesConcedidasDTO> getAutorizacoesConcedidas() {
		return autorizacoesConcedidas;
	}

	public void setAutorizacoesConcedidas(List<DashboardAutorizacoesConcedidasDTO> autorizacoesConcedidas) {
		this.autorizacoesConcedidas = autorizacoesConcedidas;
	}

}
