package br.gov.caixa.simtr.dossie.modelo.entidade;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb100_autorizacao")
@XmlRootElement
public class Autorizacao extends GenericEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identificador unico da autorização concedida", required = true)
	private Long id;
	private Long codigoNSU;
	private Calendar dataHoraRegistro;
	private Calendar dataHoraInformeNegocio;
	private String protocoloNegocio;
	private Calendar dataHoraInformeECM;
	private String protocoloECM;
	private Integer produtoOperacao;
	private Integer produtoModalidade;
	private String produtoNome;
	private String codigoClienteGED;
	private String codigoSistemaSolicitante;

	// ************************************
	private List<DocumentoAutorizacao> documentosAutorizacao;

	public Autorizacao() {
		super();
		this.documentosAutorizacao = new ArrayList<>();
	}

	@Id
	@Column(name = "nu_autorizacao")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "co_autorizacao", nullable = false)
	public Long getCodigoNSU() {
		return codigoNSU;
	}

	public void setCodigoNSU(Long codigoNSU) {
		this.codigoNSU = codigoNSU;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ts_registro", nullable = false)
	public Calendar getDataHoraRegistro() {
		return dataHoraRegistro;
	}

	public void setDataHoraRegistro(Calendar dataHoraRegistro) {
		this.dataHoraRegistro = dataHoraRegistro;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ts_informe_negocio", nullable = true)
	public Calendar getDataHoraInformeNegocio() {
		return dataHoraInformeNegocio;
	}

	public void setDataHoraInformeNegocio(Calendar dataHoraInformeNegocio) {
		this.dataHoraInformeNegocio = dataHoraInformeNegocio;
	}

	@Column(name = "co_protocolo_negocio", length = 100, nullable = true)
	public String getProtocoloNegocio() {
		return protocoloNegocio;
	}

	public void setProtocoloNegocio(String protocoloNegocio) {
		this.protocoloNegocio = protocoloNegocio;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ts_informe_ecm", nullable = true)
	public Calendar getDataHoraInformeECM() {
		return dataHoraInformeECM;
	}

	public void setDataHoraInformeECM(Calendar dataHoraInformeECM) {
		this.dataHoraInformeECM = dataHoraInformeECM;
	}

	@Column(name = "co_protocolo_ecm", length = 100, nullable = true)
	public String getProtocoloECM() {
		return protocoloECM;
	}

	public void setProtocoloECM(String protocoloECM) {
		this.protocoloECM = protocoloECM;
	}

	@Column(name = "nu_operacao", nullable = false)
	public Integer getProdutoOperacao() {
		return produtoOperacao;
	}

	public void setProdutoOperacao(Integer produtoOperacao) {
		this.produtoOperacao = produtoOperacao;
	}

	@Column(name = "nu_modalidade", nullable = false)
	public Integer getProdutoModalidade() {
		return produtoModalidade;
	}

	public void setProdutoModalidade(Integer produtoModalidade) {
		this.produtoModalidade = produtoModalidade;
	}

	@Column(name = "no_produto", length = 255, nullable = false)
	public String getProdutoNome() {
		return produtoNome;
	}

	public void setProdutoNome(String produtoNome) {
		this.produtoNome = produtoNome;
	}

	@Column(name = "co_cliente_ged", length = 255, nullable = false)
	public String getCodigoClienteGED() {
		return codigoClienteGED;
	}

	public void setCodigoClienteGED(String codigoClienteGED) {
		this.codigoClienteGED = codigoClienteGED;
	}

	@Column(name = "co_sistema_solicitante", length = 100, nullable = false)
	public String getCodigoSistemaSolicitante() {
		return codigoSistemaSolicitante;
	}

	public void setCodigoSistemaSolicitante(String codigoSistemaSolicitante) {
		this.codigoSistemaSolicitante = codigoSistemaSolicitante;
	}

	// ************************************
	@ApiModelProperty(hidden = true)
	@OneToMany(targetEntity = DocumentoAutorizacao.class, mappedBy = "autorizacao", fetch = FetchType.LAZY, cascade = {
			CascadeType.PERSIST, CascadeType.REMOVE })
	public List<DocumentoAutorizacao> getDocumentosAutorizacao() {
		return documentosAutorizacao;
	}

	public void setDocumentosAutorizacao(List<DocumentoAutorizacao> documentosAutorizacao) {
		this.documentosAutorizacao = documentosAutorizacao;
	}

	// ************************************
	public boolean addDocumentosAutorizacao(DocumentoAutorizacao... documentosAutorizacao) {
		return this.documentosAutorizacao.addAll(Arrays.asList(documentosAutorizacao));
	}

	public boolean removeDocumentosAutorizacao(DocumentoAutorizacao... documentosAutorizacao) {
		return this.documentosAutorizacao.removeAll(Arrays.asList(documentosAutorizacao));
	}

	// ************************************
	@Override
	public int hashCode() {
		int hash = 3;
		hash = 83 * hash + Objects.hashCode(this.id);
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Autorizacao other = (Autorizacao) obj;
		return Objects.equals(this.id, other.id);
	}
}
