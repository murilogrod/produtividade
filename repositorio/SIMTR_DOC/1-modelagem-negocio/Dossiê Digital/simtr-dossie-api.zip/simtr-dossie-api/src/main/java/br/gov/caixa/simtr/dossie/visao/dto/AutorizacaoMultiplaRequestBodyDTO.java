package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonProperty;

import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;

@XmlRootElement(name = "autorizacao")
@XmlAccessorType(XmlAccessType.FIELD)
public class AutorizacaoMultiplaRequestBodyDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "cpf_cnpj")
	private String cpfCnpj;
	@XmlElement(name = "tipo_pessoa")
	private TipoPessoaEnum tipoPessoa;
	@XmlElement(name = "produto")
	@XmlElementWrapper(name = "produtos")
	@JsonProperty("produtos")
	private List<ProdutoDTO> produtos;

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public TipoPessoaEnum getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(TipoPessoaEnum tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public List<ProdutoDTO> getProdutos() {
		return produtos;
	}

	public void setProdutos(List<ProdutoDTO> produtos) {
		this.produtos = produtos;
	}

}
