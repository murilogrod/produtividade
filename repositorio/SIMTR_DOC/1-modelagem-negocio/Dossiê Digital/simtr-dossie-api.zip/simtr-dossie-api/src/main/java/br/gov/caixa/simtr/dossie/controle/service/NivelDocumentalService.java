package br.gov.caixa.simtr.dossie.controle.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import br.gov.caixa.simtr.dossie.modelo.entidade.ComposicaoDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.FuncaoDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.NivelDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.RegraDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.TipoDocumento;
import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDocumentoLocalizadoDTO;

@Stateless
public class NivelDocumentalService extends AbstractService<NivelDocumental> {

	@Inject
	private EntityManager entityManager;

	@Inject
	private Logger logger;

	public List<TipoDocumento> getAll() {
		logger.info("***** Metodo TipoDocumentoServico.getAll executado *****");
		List<TipoDocumento> tipos = this.entityManager
				.createQuery("SELECT td FROM TipoDocumento td ", TipoDocumento.class).getResultList();
		this.entityManager.flush();
		return tipos;
	}

	public void atualizaNiveisDocumentaisCliente(Long cpfCnpj, TipoPessoaEnum tipoPessoa,
			List<ECMDocumentoLocalizadoDTO> documentosLocalizadosECM) {
		logger.info("***** Metodo NivelDocumentalService.atualizaNiveisDocumentaisCliente executado *****");

		List<ComposicaoDocumental> composicoesDocumentais = new ArrayList<>();

		StringBuilder jpql = new StringBuilder();
		jpql.append("SELECT DISTINCT cd FROM ComposicaoDocumental cd ");
		jpql.append("LEFT JOIN FETCH cd.regrasDocumentais rd ");
		jpql.append("LEFT JOIN FETCH cd.produtos p ");
		jpql.append("LEFT JOIN FETCH rd.tipoDocumento td ");
		jpql.append("LEFT JOIN FETCH rd.funcaoDocumental fd ");
		jpql.append("LEFT JOIN FETCH fd.tiposDocumento tds ");
		jpql.append("WHERE cd.dataHoraRevogacao IS NULL ");

		TypedQuery<ComposicaoDocumental> query = this.entityManager.createQuery(jpql.toString(),
				ComposicaoDocumental.class);

		composicoesDocumentais = query.getResultList();

		List<ComposicaoDocumental> composicoesAtendidas = new ArrayList<>();

		// Percorre todas as composições localizadas para o produto
		// solicitado
		for (ComposicaoDocumental composicaoDocumental : composicoesDocumentais) {
			Set<RegraDocumental> regrasDocumentais = composicaoDocumental.getRegrasDocumentais();

			List<ECMDocumentoLocalizadoDTO> documentosUtilizados = new ArrayList<>();
			List<RegraDocumental> regrasNaoAtendidas = new ArrayList<>();
			// Percorre todas as regras localizadas para cada composição
			for (RegraDocumental regraDocumental : regrasDocumentais) {

				// Regra atende por função documental ou tipo especifico?
				if (regraDocumental.getFuncaoDocumental() != null) {

					FuncaoDocumental funcaoDocumental = regraDocumental.getFuncaoDocumental();
					// Percorre documentos localizados no ECM em busca de um
					// da função da regra
					boolean documentoLocalizado = false;
					for (ECMDocumentoLocalizadoDTO documentoLocalizadoDTO : documentosLocalizadosECM) {
						
						Set<TipoDocumento> tiposDocumento = funcaoDocumental.getTiposDocumento();
						for (TipoDocumento tipoDocumento : tiposDocumento) {
						
							if (tipoDocumento.getNome()
									.equals(documentoLocalizadoDTO.getAtributosDocumento().getClasseDocumental())) {
								documentoLocalizado = true;
								documentosUtilizados.add(documentoLocalizadoDTO);
								break;
							}
						}
						if(documentoLocalizado){
							break;
						}
						
					}
					// Caso não localize marca regra não atendida e a função
					// documental pendente para retorno.
					if (!documentoLocalizado) {
						regrasNaoAtendidas.add(regraDocumental);
						break;
					}

				} else {

					TipoDocumento tipoDocumento = regraDocumental.getTipoDocumento();
					// Percorre documentos localizados no ECM em busca de um
					// do tipo de documento da regra
					boolean documentoLocalizado = false;
					for (ECMDocumentoLocalizadoDTO documentoLocalizadoDTO : documentosLocalizadosECM) {
						if (tipoDocumento.getNome().equals(documentoLocalizadoDTO.getAtributosDocumento().getNome())) {
							documentoLocalizado = true;
							documentosUtilizados.add(documentoLocalizadoDTO);
							break;
						}
					}
					// Caso não localize marca regra não atendida e a função
					// documental pendente para retorno.
					if (!documentoLocalizado) {
						regrasNaoAtendidas.add(regraDocumental);
						break;
					}
				}
			}
			if (regrasNaoAtendidas.isEmpty()) {
				composicoesAtendidas.add(composicaoDocumental);
			}
		}

		this.deleteAllFromCliente(cpfCnpj, tipoPessoa);
		
		for (ComposicaoDocumental composicaoAtendida : composicoesAtendidas) {
			
			NivelDocumental nivelDocumental = new NivelDocumental();
			nivelDocumental.setComposicaoDocumental(composicaoAtendida);
			nivelDocumental.setCpfCnpj(cpfCnpj);
			nivelDocumental.setTipoPessoa(tipoPessoa);

			this.save(nivelDocumental);
		}

	}

	private void deleteAllFromCliente(Long cpfCnpj, TipoPessoaEnum tipoPessoa) {
		StringBuilder jpql = new StringBuilder();
		jpql.append("DELETE FROM NivelDocumental ");
		jpql.append("WHERE cpfCnpj = :cpfCnpj ");
		jpql.append("AND tipoPessoa = :tipoPessoa ");

		Query queryExclusao = this.entityManager.createQuery(jpql.toString());

		queryExclusao.setParameter("cpfCnpj", cpfCnpj);
		queryExclusao.setParameter("tipoPessoa", tipoPessoa);

		queryExclusao.executeUpdate();

	}

	@Override
	protected EntityManager getEntityManager() {
		return this.entityManager;
	}

}
