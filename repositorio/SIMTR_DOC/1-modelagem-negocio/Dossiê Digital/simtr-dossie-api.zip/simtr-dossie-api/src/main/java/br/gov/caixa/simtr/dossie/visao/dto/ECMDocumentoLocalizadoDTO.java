package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMDocumentoLocalizadoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private String link;
	@XmlElement(name = "atributos")
	private ECMAtributosDocumentoDTO atributosDocumento;

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public ECMAtributosDocumentoDTO getAtributosDocumento() {
		return atributosDocumento;
	}

	public void setAtributosDocumento(ECMAtributosDocumentoDTO atributosDocumento) {
		this.atributosDocumento = atributosDocumento;
	}
}
