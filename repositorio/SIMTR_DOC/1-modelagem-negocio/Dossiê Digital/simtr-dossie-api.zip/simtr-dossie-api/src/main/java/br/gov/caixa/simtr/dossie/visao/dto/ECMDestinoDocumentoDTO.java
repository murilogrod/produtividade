package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

@XmlAccessorType(XmlAccessType.FIELD)
public class ECMDestinoDocumentoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private String idDocumento;
	private String transacao;
	private String tipoCliente;
	private ECMDadosPessoaFisicaDTO dadosPF;

	public String getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(String idDocumento) {
		this.idDocumento = idDocumento;
	}

	public String getTipoCliente() {
		return tipoCliente;
	}

	public String getTransacao() {
		return transacao;
	}

	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}

	public void setTipoCliente(String tipoCliente) {
		this.tipoCliente = tipoCliente;
	}

	public ECMDadosPessoaFisicaDTO getDadosPF() {
		return dadosPF;
	}

	public void setDadosPF(ECMDadosPessoaFisicaDTO dadosPF) {
		this.dadosPF = dadosPF;
	}

}
