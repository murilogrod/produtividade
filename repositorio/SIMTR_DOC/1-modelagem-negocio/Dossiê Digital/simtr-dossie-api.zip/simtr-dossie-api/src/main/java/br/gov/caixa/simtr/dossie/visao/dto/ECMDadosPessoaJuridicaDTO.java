package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

//@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMDadosPessoaJuridicaDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;
	private String cnpj;

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

}
