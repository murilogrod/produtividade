package br.gov.caixa.simtr.dossie.controle.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import br.gov.caixa.simtr.dossie.controle.service.vo.HabilitadoProdutoVO;
import br.gov.caixa.simtr.dossie.modelo.entidade.ComposicaoDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.TipoDocumento;

@Stateless
public class ComposicaoDocumentalService extends AbstractService<TipoDocumento> {

	@Inject
	private EntityManager entityManager;

	@Inject
	private Logger logger;

	public List<TipoDocumento> getAll() {
		logger.info("***** Metodo TipoDocumentoServico.getAll executado *****");
		List<TipoDocumento> tipos = this.entityManager
				.createQuery("SELECT td FROM TipoDocumento td ", TipoDocumento.class).getResultList();
		this.entityManager.flush();
		return tipos;
	}

	public List<ComposicaoDocumental> getComposicoesByProduto(Integer codigoOperacao, Integer codigoModalidade) {
		logger.info("***** Metodo ComposicaoDocumentalService.getComposicoesByProduto executado *****");

		List<ComposicaoDocumental> composicoesDocumentais = new ArrayList<>();

		StringBuilder jpql = new StringBuilder();
		jpql.append("   SELECT DISTINCT cd FROM ComposicaoDocumental cd ");
		jpql.append("   LEFT JOIN FETCH cd.regrasDocumentais rd ");
		jpql.append("   LEFT JOIN FETCH cd.produtos p ");
		jpql.append("   LEFT JOIN FETCH rd.tipoDocumento td ");
		jpql.append("   LEFT JOIN FETCH rd.funcaoDocumental fd ");
		jpql.append("   LEFT JOIN FETCH fd.tiposDocumento tds ");
		jpql.append("   WHERE p.operacao = :operacao ");
		jpql.append("   	AND p.modalidade = :modalidade ");

		TypedQuery<ComposicaoDocumental> query = this.entityManager.createQuery(jpql.toString(),
				ComposicaoDocumental.class);
		query.setParameter("operacao", codigoOperacao);
		query.setParameter("modalidade", codigoModalidade);

		composicoesDocumentais = query.getResultList();

		this.entityManager.clear();

		return composicoesDocumentais;
	}

	public List<HabilitadoProdutoVO> listHabilitadosByProduto() {
		logger.info("***** Metodo ComposicaoDocumentalService.getHabilitadosByProduto executado *****");

		List<HabilitadoProdutoVO> habilitadosProdutos = new ArrayList<>();

		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT DISTINCT ");
		jpql.append(" nu_operacao, ");
		jpql.append(" nu_modalidade, ");
		jpql.append(" no_produto, ");
		jpql.append(" COUNT(DISTINCT ND.nu_cpf_cnpj) ");
		jpql.append(" FROM dostb006_produto P ");
		jpql.append(" LEFT OUTER JOIN dostb007_produto_composicao PC ON P.nu_produto = PC.nu_produto ");
		jpql.append(
				" LEFT OUTER JOIN dostb004_composicao_documental CD ON PC.nu_composicao_documental = CD.nu_composicao_documental ");
		jpql.append(
				" LEFT OUTER JOIN dostb008_nivel_documental ND ON CD.nu_composicao_documental = ND.nu_composicao_documental ");
		jpql.append(" GROUP BY nu_operacao, nu_modalidade, no_produto");
		jpql.append(" ORDER BY no_produto");

		Query query = this.entityManager.createNativeQuery(jpql.toString());

		List<?> retorno = query.getResultList();
		for (Object registro : retorno) {
			Object[] reg = (Object[]) registro;

			Integer operacao = (Integer) reg[0];
			Integer modalidade = (Integer) reg[1];
			String produto = (String) reg[2];
			Long quantidade = ((BigInteger) reg[3]).longValue();

			habilitadosProdutos.add(new HabilitadoProdutoVO(operacao, modalidade, produto, quantidade));
		}

		return habilitadosProdutos;
	}

	@Override
	protected EntityManager getEntityManager() {
		return this.entityManager;
	}

}
