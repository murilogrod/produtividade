package br.gov.caixa.simtr.dossie.controle.service;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;

import br.gov.caixa.simtr.dossie.controle.interceptor.LazyResolveInterceptor;

/**
 * Classe responsável por prover o <b>EntityManager</b> para as classes por
 * herança e centraliza os métodos de busca mais <b>COMUNS</b> aos dados.
 * <p>
 *
 * @author c080688
 * @param <T>
 * @since 1.0
 */
@Interceptors(LazyResolveInterceptor.class)
public abstract class AbstractService<T> {

    private final Class<T> entityClass;

    protected abstract EntityManager getEntityManager();

    @SuppressWarnings("unchecked")
    public AbstractService() {
        /*
		 * Estrutura utilizada para definir a classe que foi atribuida
		 * genericamente e permitir a reflexão para a utilização do list
		 * generico
         */
        Class<?> classeDao = this.getClass();
        while (!(classeDao.getGenericSuperclass() instanceof ParameterizedType)) {
            classeDao = classeDao.getSuperclass();
        }
        ParameterizedType paramType = (ParameterizedType) (classeDao.getGenericSuperclass());
        this.entityClass = (Class<T>) (paramType.getActualTypeArguments()[0]);
    }

    /**
     * Método responsável por salvar um objeto
     *
     * @param objeto
     * @author c090347
     */
    public final void save(T objeto) {
        EntityManager entityManager = this.getEntityManager();
        entityManager.persist(objeto);
        entityManager.flush();
    }

    /**
     * Método responsável por deletar um objeto
     *
     * @param objeto
     * @author c090347
     */
    public final void delete(T objeto) {
        EntityManager entityManager = this.getEntityManager();
        entityManager.remove(objeto);
        entityManager.flush();
    }

    /**
     * Método responsável por atualizar um objeto
     *
     * @param objeto
     * @author c090347
     */
    public final void update(T objeto) {
        EntityManager entityManager = this.getEntityManager();
        entityManager.flush();
    }

    /**
     * Método responsável por buscar um objeto a partir do ID
     *
     * @param id
     * @return Object
     * @author c090347
     */
    public final T getById(Object id) {
        EntityManager entityManager = this.getEntityManager();
        return entityManager.find(this.entityClass, id);
    }

    /**
     * Método responsável por listar todos os objetos
     *
     * @return List de Objetos
     * @author c090347
     */
    public List<T> list() {
        EntityManager entityManager = this.getEntityManager();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SELECT o FROM ");
        stringBuilder.append(this.entityClass.getSimpleName());
        stringBuilder.append(" o ");
        List<T> lista = entityManager.createQuery(stringBuilder.toString(), this.entityClass).getResultList();
        entityManager.flush();
        return lista;
    }

    public final List<T> list(String... orders) {
        EntityManager entityManager = this.getEntityManager();
        StringBuilder jpql = new StringBuilder();
        jpql.append("FROM ");
        jpql.append(this.entityClass.getSimpleName());
        int qtde = orders.length;
        if (qtde > 0) {
            jpql.append(" ORDER BY ");
            for (int i = 0; i < qtde; i++) {
                jpql.append(orders[i]);
                jpql.append(",");
            }
            jpql.deleteCharAt(jpql.length() - 1);
        }
        return entityManager.createQuery(jpql.toString(), this.entityClass).getResultList();
    }
}
