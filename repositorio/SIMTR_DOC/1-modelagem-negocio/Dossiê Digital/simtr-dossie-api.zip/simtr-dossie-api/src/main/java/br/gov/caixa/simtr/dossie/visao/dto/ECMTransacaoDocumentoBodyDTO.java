package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "AnexaDocumentoTransacao")
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMTransacaoDocumentoBodyDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private ECMDadosRequisicaoDTO dadosRequisicao;
	@XmlElement(name = "destinoDocumento")
	private List<ECMDestinoDocumentoDTO> destinosDocumento;

	public ECMDadosRequisicaoDTO getDadosRequisicao() {
		return dadosRequisicao;
	}

	public void setDadosRequisicao(ECMDadosRequisicaoDTO dadosRequisicao) {
		this.dadosRequisicao = dadosRequisicao;
	}

	public List<ECMDestinoDocumentoDTO> getDestinosDocumento() {
		return destinosDocumento;
	}

	public void setDestinosDocumento(List<ECMDestinoDocumentoDTO> destinosDocumento) {
		this.destinosDocumento = destinosDocumento;
	}
}
