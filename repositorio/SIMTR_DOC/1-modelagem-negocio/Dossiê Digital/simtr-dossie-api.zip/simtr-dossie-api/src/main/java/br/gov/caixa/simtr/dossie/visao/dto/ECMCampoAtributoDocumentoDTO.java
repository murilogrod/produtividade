package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

//@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMCampoAtributoDocumentoDTO implements Serializable {

	
	@XmlTransient
	private static final long serialVersionUID = 1L;
	private String nome;
	private String valor;
	private String tipo;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


}
