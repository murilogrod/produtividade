package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;

@XmlRootElement(name = "autorizacao")
@XmlAccessorType(XmlAccessType.FIELD)
public class AutorizacaoRequestBodyDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "cpf_cnpj")
	private String cpfCnpj;
	@XmlElement(name = "tipo_pessoa")
	private TipoPessoaEnum tipoPessoa;
	@XmlElement(name = "operacao")
	private Integer operacao;
	@XmlElement(name = "modalidade")
	private Integer modalidade;

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public TipoPessoaEnum getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(TipoPessoaEnum tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public Integer getOperacao() {
		return operacao;
	}

	public void setOperacao(Integer operacao) {
		this.operacao = operacao;
	}

	public Integer getModalidade() {
		return modalidade;
	}

	public void setModalidade(Integer modalidade) {
		this.modalidade = modalidade;
	}

}
