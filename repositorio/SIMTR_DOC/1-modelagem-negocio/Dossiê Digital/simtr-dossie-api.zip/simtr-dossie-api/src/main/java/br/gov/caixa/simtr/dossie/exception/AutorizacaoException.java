package br.gov.caixa.simtr.dossie.exception;

public class AutorizacaoException extends RuntimeException {

	/**
	 * Indica que houve um problema na geração da autorização por parte do
	 * Dossiê Digital
	 */
	private static final long serialVersionUID = 1L;

	public AutorizacaoException(String message) {
		super(message);
	}

	public AutorizacaoException(String message, Throwable cause) {
		super(message, cause);
	}

}
