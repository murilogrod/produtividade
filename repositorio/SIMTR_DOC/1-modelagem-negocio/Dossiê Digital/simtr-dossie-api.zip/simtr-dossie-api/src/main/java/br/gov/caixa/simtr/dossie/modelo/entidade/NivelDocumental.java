package br.gov.caixa.simtr.dossie.modelo.entidade;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;
import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;

@Entity
@IdClass(NivelDocumentalId.class)
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb008_nivel_documental")
@XmlRootElement
public class NivelDocumental implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identificador unico do nivel documental", required = true)
	private ComposicaoDocumental composicaoDocumental;
	private Long cpfCnpj;
	private TipoPessoaEnum tipoPessoa;
	// ****************************************

	public NivelDocumental() {
		super();
	}

	@Id
	@ManyToOne(targetEntity = ComposicaoDocumental.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "nu_composicao_documental", nullable = false)
	public ComposicaoDocumental getComposicaoDocumental() {
		return composicaoDocumental;
	}

	public void setComposicaoDocumental(ComposicaoDocumental composicaoDocumental) {
		this.composicaoDocumental = composicaoDocumental;
	}

	@Id
	@Column(name = "nu_cpf_cnpj", nullable = false)
	public Long getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(Long cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	@Enumerated(EnumType.STRING)
	@Column(name = "ic_tipo_pessoa", length = 1, nullable = false)
	public TipoPessoaEnum getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(TipoPessoaEnum tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
	// ****************************************

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((composicaoDocumental == null) ? 0 : composicaoDocumental.hashCode());
		result = prime * result + ((cpfCnpj == null) ? 0 : cpfCnpj.hashCode());
		result = prime * result + ((tipoPessoa == null) ? 0 : tipoPessoa.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NivelDocumental other = (NivelDocumental) obj;
		if (composicaoDocumental == null) {
			if (other.composicaoDocumental != null)
				return false;
		} else if (!composicaoDocumental.equals(other.composicaoDocumental))
			return false;
		if (cpfCnpj == null) {
			if (other.cpfCnpj != null)
				return false;
		} else if (!cpfCnpj.equals(other.cpfCnpj))
			return false;
		if (tipoPessoa != other.tipoPessoa)
			return false;
		return true;
	}


}

class NivelDocumentalId implements Serializable {

	private static final long serialVersionUID = 1L;
	private ComposicaoDocumental composicaoDocumental;
	private Long cpfCnpj;

	public NivelDocumentalId() {
		super();
	}

	public NivelDocumentalId(ComposicaoDocumental composicaoDocumental, Long cpfCnpj) {
		super();
		this.composicaoDocumental = composicaoDocumental;
		this.cpfCnpj = cpfCnpj;
	}

	public ComposicaoDocumental getComposicaoDocumental() {
		return composicaoDocumental;
	}

	public void setComposicaoDocumental(ComposicaoDocumental composicaoDocumental) {
		this.composicaoDocumental = composicaoDocumental;
	}

	public Long getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(Long cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

}