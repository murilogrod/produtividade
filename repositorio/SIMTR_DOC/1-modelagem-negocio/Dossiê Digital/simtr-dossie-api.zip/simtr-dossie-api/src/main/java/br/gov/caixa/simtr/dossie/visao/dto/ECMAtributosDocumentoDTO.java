package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

//@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMAtributosDocumentoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;
	// Identificador do documento, para uso em outras ações, como alteração e
	// inclusão em pastas
	private String id;
	// Classe documental a qual o documento pesquisado pertence
	@XmlElement(name = "classe")
	private String classeDocumental;
	// Tipo do documento. Ex: PDF.
	@XmlElement(name = "tipo")
	private String formato;
	// MimeType do documento ex: application/pdf
	private String mimeType;
	// Nome do documento
	private String nome;
	// Campos do documento
	private List<ECMCampoAtributoDocumentoDTO> campos;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getClasseDocumental() {
		return classeDocumental;
	}

	public void setClasseDocumental(String classeDocumental) {
		this.classeDocumental = classeDocumental;
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<ECMCampoAtributoDocumentoDTO> getCampos() {
		return campos;
	}

	public void setCampos(List<ECMCampoAtributoDocumentoDTO> campos) {
		this.campos = campos;
	}
}
