package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "CriaTransacaoCliente")
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMTransacaoBodyDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private ECMDadosRequisicaoDTO dadosRequisicao;
	private String transacao;
	private String tipoCliente;
	private ECMDadosPessoaFisicaDTO dadosPF;

	public ECMDadosRequisicaoDTO getDadosRequisicao() {
		return dadosRequisicao;
	}

	public void setDadosRequisicao(ECMDadosRequisicaoDTO dadosRequisicao) {
		this.dadosRequisicao = dadosRequisicao;
	}

	public String getTipoCliente() {
		return tipoCliente;
	}

	public String getTransacao() {
		return transacao;
	}

	public void setTransacao(String transacao) {
		this.transacao = transacao;
	}

	public void setTipoCliente(String tipoCliente) {
		this.tipoCliente = tipoCliente;
	}

	public ECMDadosPessoaFisicaDTO getDadosPF() {
		return dadosPF;
	}

	public void setDadosPF(ECMDadosPessoaFisicaDTO dadosPF) {
		this.dadosPF = dadosPF;
	}

}
