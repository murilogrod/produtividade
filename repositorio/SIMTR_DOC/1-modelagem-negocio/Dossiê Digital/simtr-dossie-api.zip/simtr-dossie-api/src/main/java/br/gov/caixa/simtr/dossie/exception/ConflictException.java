package br.gov.caixa.simtr.dossie.exception;

public class ConflictException extends RuntimeException {

    /**
     * CODIGO 409 - CONFLICT - Indica que a solicitação não pôde ser processada
     * por causa do conflito no pedido, como um conflito de edição
     */
    private static final long serialVersionUID = 1L;

    public ConflictException(String message) {
        super(message);
    }

}
