package br.gov.caixa.simtr.dossie.modelo.entidade;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb002_funcao_documental", indexes = {
    @Index(name = "ix_dostb006_01", unique = true, columnList = "no_funcao")
})
@XmlRootElement
public class FuncaoDocumental extends GenericEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "Identificador unico da função documental", required = true)
    private Integer id;
    private String nome;
    private Boolean ativo;
    // *************************************************
    private Set<TipoDocumento> tiposDocumento;
    private Set<RegraDocumental> regrasDocumentais;

    public FuncaoDocumental() {
        super();
//        this.tiposDocumento = new ArrayList<>();
//        this.regrasDocumentais = new ArrayList<>();
        this.ativo = true;
    }

    @Id
    @Column(name = "nu_funcao_documental")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "no_funcao", nullable = false, length = 100, unique = true)
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Column(name = "ic_ativo", nullable = false)
    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }

    //***************************************************
//    @JsonInclude(value = Include.NON_EMPTY)
    @ApiModelProperty(hidden = true)
    @ManyToMany(targetEntity = TipoDocumento.class, mappedBy = "funcoesDocumentais", fetch = FetchType.LAZY)
    public Set<TipoDocumento> getTiposDocumento() {
        return tiposDocumento;
    }

    public void setTiposDocumento(Set<TipoDocumento> tiposDocumento) {
        this.tiposDocumento = tiposDocumento;
    }

//    @JsonInclude(value = Include.NON_EMPTY)
    @ApiModelProperty(hidden = true)
    @OneToMany(targetEntity = RegraDocumental.class, mappedBy = "funcaoDocumental", fetch = FetchType.LAZY)
    public Set<RegraDocumental> getRegrasDocumentais() {
        return regrasDocumentais;
    }

    public void setRegrasDocumentais(Set<RegraDocumental> regrasDocumentais) {
        this.regrasDocumentais = regrasDocumentais;
    }

    //***************************************************
    public boolean addTiposDocumento(TipoDocumento... tiposDocumento) {
        return this.tiposDocumento.addAll(Arrays.asList(tiposDocumento));
    }

    public boolean removeTiposDocumento(TipoDocumento... tiposDocumento) {
        return this.tiposDocumento.removeAll(Arrays.asList(tiposDocumento));
    }

    public boolean addRegrasDocumentais(RegraDocumental... regrasDocumentais) {
        return this.regrasDocumentais.addAll(Arrays.asList(regrasDocumentais));
    }

    public boolean removeRegrasDocumentais(RegraDocumental... regrasDocumentais) {
        return this.regrasDocumentais.removeAll(Arrays.asList(regrasDocumentais));
    }

    //***************************************************
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 41 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final FuncaoDocumental other = (FuncaoDocumental) obj;
        return Objects.equals(this.id, other.id);
    }
}
