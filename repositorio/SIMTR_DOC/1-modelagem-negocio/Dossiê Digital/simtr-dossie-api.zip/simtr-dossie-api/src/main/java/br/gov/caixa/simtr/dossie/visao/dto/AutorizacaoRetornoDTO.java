package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;
import br.gov.caixa.simtr.dossie.visao.adapter.CalendarFullAdapter;
import io.swagger.annotations.ApiModelProperty;

@XmlRootElement(name = "autorizacao")
@XmlAccessorType(XmlAccessType.FIELD)
public class AutorizacaoRetornoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	// Ticket de acesso ao documento requisitado.
	@XmlElement(name = "autorizacao")
	@JsonInclude(value = Include.NON_EMPTY)
	private Long codigoAutorizacao;
	@XmlElement(name = "autorizado")
	private boolean autorizado;
	@XmlElement(name = "produto_localizado")
	private boolean produtoLocalizado;
	@XmlJavaTypeAdapter(CalendarFullAdapter.class)
	@XmlElement(name = "data_hora")
	private Calendar dataHoraAutorizacao;
	@XmlElement(name = "cpf_cnpj")
	private String cpfCnpj;
	@XmlElement(name = "tipo_pessoa")
	private TipoPessoaEnum tipoPessoa;
	@XmlElement(name = "operacao")
	private Integer operacao;
	@XmlElement(name = "modalidade")
	private Integer modalidade;
	@XmlElement(name = "produto")
	private String nomeProduto;
	@JsonInclude(value = Include.NON_EMPTY)
	@XmlElementWrapper(name = "pendencias")
	@XmlElement(name = "documentos_pendentes")
	private List<String> documentosAusentes;
	@XmlElement(name = "observacao")
	private String observacao;
	@XmlTransient
	@ApiModelProperty(hidden = true)
	private List<ECMDocumentoLocalizadoDTO> documentosUtilizados;

	public AutorizacaoRetornoDTO() {
		super();
		this.dataHoraAutorizacao = Calendar.getInstance();
	}

	public Long getCodigoAutorizacao() {
		return codigoAutorizacao;
	}

	public void setCodigoAutorizacao(Long codigoAutorizacao) {
		this.codigoAutorizacao = codigoAutorizacao;
	}

	public boolean isAutorizado() {
		return autorizado;
	}

	public void setAutorizado(boolean autorizado) {
		this.autorizado = autorizado;
	}

	public boolean isProdutoLocalizado() {
		return produtoLocalizado;
	}

	public void setProdutoLocalizado(boolean produtoLocalizado) {
		this.produtoLocalizado = produtoLocalizado;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public TipoPessoaEnum getTipoPessoa() {
		return tipoPessoa;
	}

	public void setTipoPessoa(TipoPessoaEnum tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public Integer getOperacao() {
		return operacao;
	}

	public void setOperacao(Integer operacao) {
		this.operacao = operacao;
	}

	public Integer getModalidade() {
		return modalidade;
	}

	public void setModalidade(Integer modalidade) {
		this.modalidade = modalidade;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public List<String> getDocumentosAusentes() {
		return documentosAusentes;
	}

	public void setDocumentosAusentes(List<String> documentosAusentes) {
		this.documentosAusentes = documentosAusentes;
	}

	// **********************************

	public String getObservacao() {
		return observacao;
	}

	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	public List<ECMDocumentoLocalizadoDTO> getDocumentosUtilizados() {
		return documentosUtilizados;
	}

	public void setDocumentosUtilizados(List<ECMDocumentoLocalizadoDTO> documentosUtilizados) {
		this.documentosUtilizados = documentosUtilizados;
	}

}
