package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlTransient;

public class DashboardProdutoHabilitadoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private Integer operacao;
	private Integer modalidade;
	private String produto;
	private Long quantidade;

	public DashboardProdutoHabilitadoDTO() {
		super();
	}

	public DashboardProdutoHabilitadoDTO(Integer operacao, Integer modalidade, String produto, Long quantidade) {
		super();
		this.operacao = operacao;
		this.modalidade = modalidade;
		this.produto = produto;
		this.quantidade = quantidade;
	}
	
	public Integer getOperacao() {
		return operacao;
	}

	public void setOperacao(Integer operacao) {
		this.operacao = operacao;
	}

	public Integer getModalidade() {
		return modalidade;
	}

	public void setModalidade(Integer modalidade) {
		this.modalidade = modalidade;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public Long getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Long quantidade) {
		this.quantidade = quantidade;
	}

}
