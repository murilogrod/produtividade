package br.gov.caixa.simtr.dossie.visao.rest.interceptor;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import br.gov.caixa.simtr.dossie.visao.dto.ResourceError;

@Provider
public class RESTConstrainViolationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {

    @Inject
    private Logger log;

    @Override
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response toResponse(ConstraintViolationException e) {

        log.info("Chamada a classe BeanValConstrainViolationExceptionMapper");

        /**
         * INSERCAO DE VARIOS ERROS
         */
        Set<ConstraintViolation<?>> violations = e.getConstraintViolations();

        List<ResourceError> contraitsViolated = new ArrayList<>();

        for (ConstraintViolation<?> violation : violations) {

            String[] campo = violation.getPropertyPath().toString().split("\\.");

            ResourceError resourceError = new ResourceError();

            resourceError.setDetail("Valor informado: " + violation.getInvalidValue().toString());
            resourceError.setCode(22);
            resourceError.setMessage("Falha ao validar o campo " + campo[campo.length - 1] + ". Regra violada: " + violation.getMessage());

            contraitsViolated.add(resourceError);
        }

        contraitsViolated.forEach(erros -> log.log(Level.INFO, "ERRO ENCONTRADO NA VALIDACAO RELIZADO PELA CLASSE BeanValConstrainViolationExceptionMapper: {0}", erros.getMessage()));

        return Response.status(Response.Status.BAD_REQUEST).entity(contraitsViolated).build();

    }
}
