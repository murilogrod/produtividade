/**
 * Copyright (c) 2017 Caixa Econômica Federal. Todos os direitos
 * reservados.
 *
 * Caixa Econômica Federal - sidos
 *
 * Este software foi desenvolvido sob demanda da CAIXA e está
 * protegido por leis de direitos autorais e tratados internacionais. As
 * condições de cópia e utilização do todo ou partes dependem de autorização da
 * empresa. Cópias não são permitidas sem expressa autorização. Não pode ser
 * comercializado ou utilizado para propósitos particulares.
 *
 * Uso exclusivo da Caixa Econômica Federal. A reprodução ou distribuição não
 * autorizada deste programa ou de parte dele, resultará em punições civis e
 * criminais e os infratores incorrem em sanções previstas na legislação em
 * vigor.
 */
package br.gov.caixa.simtr.dossie.util;

import br.gov.caixa.simtr.dossie.visao.enumerator.AcaoECMEnum;

/**
 * <p>
 * Constantes
 * </p>
 * <p>
 * Descrição: classe responsável por armazenar constantes referente a base de
 * dados
 * </p>
 * <br>
 * <b>Empresa:</b> Cef - Caixa Econômica Federal
 *
 * @author ricardo.crispim
 * @version 1.0
 */
public interface Constantes {

	/**
	 * Atributo CHARSET.
	 */
	public final String CHARSET = "utf-8";

	/**
	 * Atributo NOME_SCHEMA.
	 */
	public final String DATABASE_SCHEMA = "dossm001";

	/**
	 * Atributo PERSISTENCE_UNIT.
	 */
	public final String PERSISTENCE_UNIT = "sidosPU";

	/**
	 * Constantes para comunicação com ECM. Endpoints localizados em enumerator.
	 * 
	 * @see AcaoECMEnum
	 */
	public final String ECM_URL_BASE = "http://siecm.des.caixa/siecm-web/";
	public final String ECM_OBJECT_STORE = "OS_CAIXA";

	public final Integer ECM_RETORNO_SUCESSO = 0;
	public final Integer ECM_RETORNO_ERRO_PROCESSAMENTO = 1;
	public final Integer ECM_RETORNO_ERRO_INFRA = 2;
}
