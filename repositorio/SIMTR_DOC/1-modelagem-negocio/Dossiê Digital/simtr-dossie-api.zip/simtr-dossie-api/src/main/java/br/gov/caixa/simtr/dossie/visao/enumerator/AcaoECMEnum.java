package br.gov.caixa.simtr.dossie.visao.enumerator;

public enum AcaoECMEnum {

	ANEXA_DOCUMENTOS_TRANSACAO("ECM/reuso/dossie/documentoTransacao"), 
	CRIA_TRANSACAO_CLIENTE("ECM/reuso/dossie/transacao/cliente"), 
	LISTA_CONTEUDO_DOSSIE("ECM/reuso/dossie/listaDocumentos");

	private String endPoint;

	AcaoECMEnum(String endPoint) {
		this.endPoint = endPoint;
	}

	public String getEndPoint() {
		return endPoint;
	}

}
