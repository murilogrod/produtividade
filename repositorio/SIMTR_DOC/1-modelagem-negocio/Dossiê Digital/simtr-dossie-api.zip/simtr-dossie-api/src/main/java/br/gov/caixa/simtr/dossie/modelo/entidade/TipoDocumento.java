package br.gov.caixa.simtr.dossie.modelo.entidade;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb001_tipo_documento")
@XmlRootElement(name = "tipo_documento")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "id", "nome", "tipologia" })
public class TipoDocumento extends GenericEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Identificador unico do tipo de documento", required = true)
	private Integer id;
	private String nome;
	private String tipologia;
	// ***********************************
	private Set<FuncaoDocumental> funcoesDocumentais;
	private Set<RegraDocumental> regrasDocumentais;

	public TipoDocumento() {
		super();
		// this.funcoesDocumentais = new ArrayList<>();
		// this.regrasDocumentais = new ArrayList<>();
	}

	@Id
	@Column(name = "nu_tipo_documento")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "no_tipo_documento", nullable = false, length = 100)
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Column(name = "co_tipologia", nullable = false, length = 100)
	public String getTipologia() {
		return tipologia;
	}

	public void setTipologia(String tipologia) {
		this.tipologia = tipologia;
	}

	// ***********************************
	@JsonInclude(Include.NON_NULL)
	@ApiModelProperty(hidden = true)
	@ManyToMany(targetEntity = FuncaoDocumental.class, fetch = FetchType.LAZY)
	@JoinTable(schema = Constantes.DATABASE_SCHEMA, name = "dostb003_funcao_documento", joinColumns = {
			@JoinColumn(name = "nu_tipo_documento", referencedColumnName = "nu_tipo_documento") }, inverseJoinColumns = {
					@JoinColumn(name = "nu_funcao_documental", referencedColumnName = "nu_funcao_documental") })

	public Set<FuncaoDocumental> getFuncoesDocumentais() {
		return funcoesDocumentais;
	}

	public void setFuncoesDocumentais(Set<FuncaoDocumental> funcoesDocumentais) {
		this.funcoesDocumentais = funcoesDocumentais;
	}

	@JsonInclude(Include.NON_NULL)
	@ApiModelProperty(hidden = true)
	@OneToMany(targetEntity = RegraDocumental.class, mappedBy = "tipoDocumento", fetch = FetchType.LAZY)
	public Set<RegraDocumental> getRegrasDocumentais() {
		return regrasDocumentais;
	}

	public void setRegrasDocumentais(Set<RegraDocumental> regrasDocumentais) {
		this.regrasDocumentais = regrasDocumentais;
	}

	// ***********************************
	public boolean addFuncoesDocumentais(FuncaoDocumental... funcoesDocumentais) {
		return this.funcoesDocumentais.addAll(Arrays.asList(funcoesDocumentais));
	}

	public boolean removeFuncoesDocumentais(FuncaoDocumental... funcoesDocumentais) {
		return this.funcoesDocumentais.removeAll(Arrays.asList(funcoesDocumentais));
	}

	public boolean addRegrasDocumentais(RegraDocumental... regrasDocumentais) {
		return this.regrasDocumentais.addAll(Arrays.asList(regrasDocumentais));
	}

	public boolean removeRegrasDocumentais(RegraDocumental... regrasDocumentais) {
		return this.regrasDocumentais.removeAll(Arrays.asList(regrasDocumentais));
	}

	// ***********************************
	@Override
	public int hashCode() {
		int hash = 5;
		hash = 61 * hash + Objects.hashCode(this.id);
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final TipoDocumento other = (TipoDocumento) obj;
		return Objects.equals(this.id, other.id);
	}
}
