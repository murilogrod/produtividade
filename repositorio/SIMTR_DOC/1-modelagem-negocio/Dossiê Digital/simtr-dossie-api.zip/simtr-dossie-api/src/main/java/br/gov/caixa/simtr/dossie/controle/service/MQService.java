package br.gov.caixa.simtr.dossie.controle.service;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.jboss.ejb3.annotation.ResourceAdapter;

@MessageDriven(name = "ConsumidorMDBSipes", activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		// @ActivationConfigProperty(propertyName = "messagingType",
		// propertyValue = "javax.jms.MessageListener"),
		@ActivationConfigProperty(propertyName = "useJNDI", propertyValue = "false"),
		@ActivationConfigProperty(propertyName = "hostName", propertyValue = "10.192.224.100"),
		@ActivationConfigProperty(propertyName = "port", propertyValue = "1415"),
		@ActivationConfigProperty(propertyName = "channel", propertyValue = "SIBAR.SVRCONN"),
		@ActivationConfigProperty(propertyName = "queueManager", propertyValue = "BRD3"),
		@ActivationConfigProperty(propertyName = "username", propertyValue = "SMNTDB01"),
		// @ActivationConfigProperty(propertyName = "destination", propertyValue
		// = "MQ.QUEUE.NAME"),
		@ActivationConfigProperty(propertyName = "transportType", propertyValue = "CLIENT") })

@ResourceAdapter(value = "wmq.jmsra.rar")
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)

@Stateless
public class MQService implements MessageListener {

	@Resource(mappedName = "java:jboss/jms/SIPESQueueConnectionFactory")
	private QueueConnectionFactory connectionFactory;

	@Resource(mappedName = "java:jboss/jms/SIBAR.REQ.PESQUISA_CADASTRAL")
	private Queue queuePergunta;

	@Resource(mappedName = "java:jboss/jms/SIBAR.RSP.PESQUISA_CADASTRAL")
	private Queue queueResposta;

	@Override
	public void onMessage(Message arg0) {
		// TODO Auto-generated method stub
		System.out.println("RECEBEU UMA MENSAGEM!!!");
	}

	public String sendMessage() {
		Session session = null;
		Connection conn = null;
		MessageConsumer consumer = null;
		MessageProducer producer = null;

		try {

			conn = this.connectionFactory.createQueueConnection();
			conn.start();
			session = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);

		} catch (JMSException je) {
			throw new RuntimeException("ERRO AO CRIAR CONNECTION FACTORY", je);
		}

		try {

			TextMessage message = session.createTextMessage(criaMensagemExemploSIPES());
			message.clearProperties();

			// message.setJMSDestination(queuePergunta);

			// message.setJMSReplyTo(queueResposta);

			producer = session.createProducer(queuePergunta);

			producer.send(message);

			String selector = "JMSCorrelationID='" + message.getJMSMessageID().toUpperCase() + "'";

			consumer = session.createConsumer(queueResposta, selector);

			message = (TextMessage) consumer.receive(10000L);

			if (message == null) {
				// Se a mensagem está vazia, então ocorreu um timeout no acesso
				// a fila do MQ
				throw new RuntimeException("TIMEOUT NO MQ");

			}

			// //Verifica se a opção se log para as mensagens da processadora
			// esta ativa
			// if (logAtivado != null && logAtivado.equals(Constantes.TRUE)) {
			//
			// String mensagemLog;
			// //grava no log a mensagem recebida do sicpf
			// if (sistemaEnvio.equals("SICPF")) {
			// mensagemLog = "DATA: " + Util.formatData(new Date(),
			// Constantes.DATA_FORMATO_LOG) + "\n" +
			// "EVENTO: Processo de Adesão Online\n" +
			// "PROCESSO: XML recebida do SICPF:\n" +
			// message.getText() + "\n" +
			// "*******************************************************************";
			// } else {
			// mensagemLog = "DATA: " + Util.formatData(new Date(),
			// Constantes.DATA_FORMATO_LOG) + "\n" +
			// "EVENTO: Processo de Adesão Online\n" +
			// "PROCESSO: XML recebida do SIPES:\n" +
			// message.getText() + "\n" +
			// "*******************************************************************";
			// }
			//
			// logger.info(mensagemLog);
			// }
			return message.getText();

		} catch (JMSException jme) {
			throw new RuntimeException("ERRO AO MANIUPULAR MENSAGEM DO SIPES", jme);
		} finally {
			// fecharConexoes(conn, session, consumer, producer);
		}
	}

	private String criaMensagemExemploSIPES() {
		return "<pesquisacadastral:SERVICO_ENTRADA xmlns:pesquisacadastral=\"http://caixa.gov.br/sibar/pesquisa_cadastral\"  	xmlns:sibar_base=\"http://caixa.gov.br/sibar\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><sibar_base:HEADER><VERSAO>1.0</VERSAO><OPERACAO>PESQUISA_CADASTRAL</OPERACAO><SISTEMA_ORIGEM>SIDOS</SISTEMA_ORIGEM><IDENTIFICADOR_ORIGEM>dt7261lx231</IDENTIFICADOR_ORIGEM><DATA_HORA>20171220132514</DATA_HORA></sibar_base:HEADER><DADOS><TP_PESSOA>1</TP_PESSOA><CPF>73662585634</CPF><FLAG_SERASA>S</FLAG_SERASA><FLAG_CADIN>S</FLAG_CADIN><FLAG_SINAD>S</FLAG_SINAD><FLAG_CCF>S</FLAG_CCF><FLAG_SPC>S</FLAG_SPC><FLAG_SICOW>S</FLAG_SICOW></DADOS></pesquisacadastral:SERVICO_ENTRADA>";
	}
}
