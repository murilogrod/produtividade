package br.gov.caixa.simtr.dossie.modelo.entidade;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import br.gov.caixa.simtr.dossie.util.Constantes;
import io.swagger.annotations.ApiModelProperty;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@Table(schema = Constantes.DATABASE_SCHEMA, name = "dostb005_regra_documental")
@XmlRootElement
public class RegraDocumental extends GenericEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "Identificador unico da regra documental", required = true)
    private Integer id;
    private ComposicaoDocumental composicaoDocumental;
    private TipoDocumento tipoDocumento;
    private FuncaoDocumental funcaoDocumental;
    private Double indiceAntifraude;

    // **********************************
    public RegraDocumental() {
        super();
    }

    @Id
    @Column(name = "nu_regra_documental")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @ManyToOne(targetEntity = ComposicaoDocumental.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "nu_composicao_documental", nullable = false)
    public ComposicaoDocumental getComposicaoDocumental() {
        return composicaoDocumental;
    }

    public void setComposicaoDocumental(ComposicaoDocumental composicaoDocumental) {
        this.composicaoDocumental = composicaoDocumental;
    }

    @ManyToOne(targetEntity = TipoDocumento.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "nu_tipo_documento", nullable = true)
    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    @ManyToOne(targetEntity = FuncaoDocumental.class, fetch = FetchType.LAZY)
    @JoinColumn(name = "nu_funcao_documental", nullable = true)
    public FuncaoDocumental getFuncaoDocumental() {
        return funcaoDocumental;
    }

    public void setFuncaoDocumental(FuncaoDocumental funcaoDocumental) {
        this.funcaoDocumental = funcaoDocumental;
    }

    @Column(name = "in_antifraude", scale = 10, precision = 5, nullable = true)
    public Double getIndiceAntifraude() {
        return indiceAntifraude;
    }

    public void setIndiceAntifraude(Double indiceAntifraude) {
        this.indiceAntifraude = indiceAntifraude;
    }

    // **********************************
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.id);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final RegraDocumental other = (RegraDocumental) obj;
        return Objects.equals(this.id, other.id);
    }

}
