package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@XmlRootElement(name = "PesquisaDossie")
@XmlAccessorType(XmlAccessType.FIELD)
public class ECMPesquisaBodyDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	private ECMDadosRequisicaoDTO dadosRequisicao;
	private String tipoCliente;
	@JsonInclude(value = Include.NON_NULL)
	private ECMDadosPessoaFisicaDTO dadosPF;
	@JsonInclude(value = Include.NON_NULL)
	private ECMDadosPessoaJuridicaDTO dadosPJ;

	public ECMDadosRequisicaoDTO getDadosRequisicao() {
		return dadosRequisicao;
	}

	public void setDadosRequisicao(ECMDadosRequisicaoDTO dadosRequisicao) {
		this.dadosRequisicao = dadosRequisicao;
	}

	public String getTipoCliente() {
		return tipoCliente;
	}

	public void setTipoCliente(String tipoCliente) {
		this.tipoCliente = tipoCliente;
	}

	public ECMDadosPessoaFisicaDTO getDadosPF() {
		return dadosPF;
	}

	public void setDadosPF(ECMDadosPessoaFisicaDTO dadosPF) {
		this.dadosPF = dadosPF;
	}

	public ECMDadosPessoaJuridicaDTO getDadosPJ() {
		return dadosPJ;
	}

	public void setDadosPJ(ECMDadosPessoaJuridicaDTO dadosPJ) {
		this.dadosPJ = dadosPJ;
	}

}
