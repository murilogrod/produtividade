package br.gov.caixa.simtr.dossie.visao.dto;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlAccessorType(XmlAccessType.FIELD)
public class DashboardResumoAutorizacaoDTO implements Serializable {

	@XmlTransient
	private static final long serialVersionUID = 1L;

	@XmlElement(name = "periodo")
	private String periodo;
	@XmlElement(name = "quantidade")
	private Long quantidade;

	public DashboardResumoAutorizacaoDTO(String periodo, Long quantidade) {
		super();
		this.periodo = periodo;
		this.quantidade = quantidade;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}

	public Long getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(Long quantidade) {
		this.quantidade = quantidade;
	}

}
