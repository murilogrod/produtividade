package br.gov.caixa.simtr.dossie.controle.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TemporalType;

import br.gov.caixa.simtr.dossie.exception.AutorizacaoException;
import br.gov.caixa.simtr.dossie.modelo.entidade.Autorizacao;
import br.gov.caixa.simtr.dossie.modelo.entidade.ComposicaoDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.DocumentoAutorizacao;
import br.gov.caixa.simtr.dossie.modelo.entidade.FuncaoDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.Produto;
import br.gov.caixa.simtr.dossie.modelo.entidade.RegraDocumental;
import br.gov.caixa.simtr.dossie.modelo.entidade.TipoDocumento;
import br.gov.caixa.simtr.dossie.modelo.enumerator.TipoPessoaEnum;
import br.gov.caixa.simtr.dossie.visao.dto.AutorizacaoRetornoDTO;
import br.gov.caixa.simtr.dossie.visao.dto.ECMDocumentoLocalizadoDTO;

@Stateless
public class AutorizacaoService extends AbstractService<Autorizacao> {

	@Inject
	private EntityManager entityManager;
	@Inject
	private ComposicaoDocumentalService composicaoDocumentalService;

	@Inject
	private Logger logger;

	/**
	 * Método responsável por gerar uma autorização para contratação de um
	 * produto;<br>
	 * Para realizar essa ação, o método realiza dos seguintes passos: <br>
	 * <ol>
	 * <li>Identifica as composições documentais cadastradas para a operação e
	 * modalidade solicitada</li>
	 * <ol>
	 * <li>Caso não seja localizado nenhuma composição é retornado uma negativa
	 * informando que o produto não foi localizado</li>
	 * </ol>
	 * <li>Analisa os documentos do cliente x compsoições documentais da
	 * seguinte forma:</li>
	 * <ol>
	 * <li>Percorre todas as composições de documento, para cada
	 * composição;</li>
	 * <li>Percorre todas as regras documentais vinculadas;</li>
	 * <li>Para cada regra documental localizada, percorre os documentos do
	 * cliente localizados no ECM e caso encontre documento valido armazena
	 * documento utilizado e pula para proxima regra, caso contrario para marca
	 * que o documento especifico ou função documental não foi localizado
	 * conforme o caso e pula para a proxima regra. Repete até não ter mais
	 * regras;</li>
	 * </ol>
	 * <li>Ao terminar o ciclo:</li>
	 * <ul>
	 * <li>Caso não tenha atendido a nenhuma composição documental, retorna o
	 * objeto de autorização com a negativa a lista de documentos ausentes</li>
	 * <li>Caso tenha atendido a pelo menos uma composição documental, cria o
	 * NSU da autorização, atribui os documentos utilizados na autorização,
	 * salva a autorização na base e retorna o objeto com o codigo de
	 * autorização</li>
	 * </ul>
	 * </ol>
	 * 
	 * @param cpfCnpj
	 *            Numero do CPF/CNPJ do cliente encaminhado na requisição
	 * @param tipoPessoa
	 *            Tipo de pessoa identificado
	 * @param operacao
	 *            Código da operação CAIXA que deseja solicitar a autorização
	 * @param modalidade
	 *            - Código da modalidade especifica do produto desejado
	 * @param documentosLocalizadosECM
	 *            Lista de metadados dos documentos presentes identificados no
	 *            dossiê do cliente junto ao ECM
	 * @param sistemaSolicitante
	 *            Identificação do sistema responsavel pela solicitação da
	 *            autorização para armazenamento
	 * @return Objeto de autorização contendo o codigo NSU da autorização caso a
	 *         operação tenha sido bem sucedida ou em caso negativo o motivo da
	 *         rejeição
	 */
	public AutorizacaoRetornoDTO requestAutorizacao(String cpfCnpj, TipoPessoaEnum tipoPessoa, Integer operacao,
			Integer modalidade, List<ECMDocumentoLocalizadoDTO> documentosLocalizadosECM, String sistemaSolicitante) {
		try {
			List<RegraDocumental> regrasAtendidas = new ArrayList<>();
			List<ECMDocumentoLocalizadoDTO> documentosUtilizados = new ArrayList<>();
			List<RegraDocumental> regrasNaoAtendidas = new ArrayList<>();
			List<String> documentosAusentes = new ArrayList<>();

			List<ComposicaoDocumental> composicoesDocumentais = this.composicaoDocumentalService
					.getComposicoesByProduto(operacao, modalidade);

			AutorizacaoRetornoDTO autorizacaoRetornoDTO = new AutorizacaoRetornoDTO();
			autorizacaoRetornoDTO.setCpfCnpj(cpfCnpj);
			autorizacaoRetornoDTO.setTipoPessoa(tipoPessoa);
			autorizacaoRetornoDTO.setOperacao(operacao);
			autorizacaoRetornoDTO.setModalidade(modalidade);

			// Caso não sejam localizadas composições retorna indicação da
			// negativa
			if (composicoesDocumentais.isEmpty()) {
				autorizacaoRetornoDTO.setProdutoLocalizado(false);
				return autorizacaoRetornoDTO;
			}

			Produto produtoSolicitado = composicoesDocumentais.get(0).getProdutos().iterator().next();
			autorizacaoRetornoDTO.setNomeProduto(produtoSolicitado.getNome());
			autorizacaoRetornoDTO.setProdutoLocalizado(true);

			// Percorre todas as composições localizadas para o produto
			// solicitado
			for (ComposicaoDocumental composicaoDocumental : composicoesDocumentais) {
				Set<RegraDocumental> regrasDocumentais = composicaoDocumental.getRegrasDocumentais();
				// Percorre todas as regras localizadas para cada composição
				for (RegraDocumental regraDocumental : regrasDocumentais) {
					// Regra atende por função documental ou tipo especifico?
					if (regraDocumental.getFuncaoDocumental() != null) {
						FuncaoDocumental funcaoDocumental = regraDocumental.getFuncaoDocumental();
						// Percorre documentos localizados no ECM em busca de um
						// da função da regra
						boolean documentoLocalizado = false;
						for (ECMDocumentoLocalizadoDTO documentoLocalizadoDTO : documentosLocalizadosECM) {
							Set<TipoDocumento> tiposDocumento = funcaoDocumental.getTiposDocumento();
							for (TipoDocumento tipoDocumento : tiposDocumento) {

								if (tipoDocumento.getNome()
										.equals(documentoLocalizadoDTO.getAtributosDocumento().getClasseDocumental())) {

									documentoLocalizado = true;
									regrasAtendidas.add(regraDocumental);
									documentosUtilizados.add(documentoLocalizadoDTO);
									break;
								}
							}
							if (documentoLocalizado) {
								break;
							}

						}
						// Caso não localize marca regra não atendida e a função
						// documental pendente para retorno.
						if (!documentoLocalizado) {
							regrasNaoAtendidas.add(regraDocumental);
							documentosAusentes.add(funcaoDocumental.getNome());
						}
					} else {
						TipoDocumento tipoDocumento = regraDocumental.getTipoDocumento();
						// Percorre documentos localizados no ECM em busca de um
						// do tipo de documento da regra
						boolean documentoLocalizado = false;
						for (ECMDocumentoLocalizadoDTO documentoLocalizadoDTO : documentosLocalizadosECM) {
							if (tipoDocumento.getNome()
									.equals(documentoLocalizadoDTO.getAtributosDocumento().getNome())) {
								documentoLocalizado = true;
								regrasAtendidas.add(regraDocumental);
								documentosUtilizados.add(documentoLocalizadoDTO);
								break;
							}
						}
						// Caso não localize marca regra não atendida e a função
						// documental pendente para retorno.
						if (!documentoLocalizado) {
							regrasNaoAtendidas.add(regraDocumental);
							documentosAusentes.add(tipoDocumento.getNome());
						}
					}
				}
				if(documentosAusentes.isEmpty()){
					break;
				}
			}

			if (regrasNaoAtendidas.size() > 0) {
				autorizacaoRetornoDTO.setDocumentosAusentes(documentosAusentes);
			} else {
				Autorizacao autorizacao = this.createAutorizacao(String.valueOf(cpfCnpj), produtoSolicitado,
						documentosUtilizados, sistemaSolicitante);
				autorizacaoRetornoDTO.setAutorizado(true);
				autorizacaoRetornoDTO.setCodigoAutorizacao(autorizacao.getCodigoNSU());
				autorizacaoRetornoDTO.setDocumentosUtilizados(documentosUtilizados);
			}
			return autorizacaoRetornoDTO;
		} catch (RuntimeException re) {
			throw new AutorizacaoException("requestAutorizacao: " + re.getMessage(), re.getCause());
		}

	}

	public boolean updateInformeECM(Long codigoAutorizacao, String protocoloECM) {
		try {
			StringBuilder jpql = new StringBuilder();
			jpql.append(
					"UPDATE Autorizacao a SET a.dataHoraInformeECM = :dataHora, protocoloECM = :protocoloECM WHERE codigoNSU = :codigoNSU ");

			Query query = this.entityManager.createQuery(jpql.toString());
			query.setParameter("codigoNSU", codigoAutorizacao);
			query.setParameter("protocoloECM", protocoloECM);
			query.setParameter("dataHora", Calendar.getInstance());

			int registrosAlterados = query.executeUpdate();
			this.logger.info("AS001 - Registro de autorização " + codigoAutorizacao + " com informeECM atualizado.");
			return registrosAlterados > 0 ? true : false;
		} catch (RuntimeException re) {
			this.logger.info("AS.RE.001 - Falha ao atualizar o registro de autorização.");
			throw new AutorizacaoException("updateInformeECM: " + re.getMessage(), re.getCause());
		}
	}

	public void invalidaPorFalhaECM(Long codigoAutorizacao, String mensagemFalha) {
		try {
			mensagemFalha = mensagemFalha.length() > 90 ? "FalhaECM: " + mensagemFalha.substring(0, 90)
					: "FalhaECM: " + mensagemFalha;

			StringBuilder jpql = new StringBuilder();
			jpql.append(
					"UPDATE Autorizacao SET dataHoraInformeECM = :dataHora, protocoloECM = :protocoloECM WHERE codigoNSU = :codigoNSU ");

			Query query = this.entityManager.createQuery(jpql.toString());
			query.setParameter("codigoNSU", codigoAutorizacao);
			query.setParameter("protocoloECM", mensagemFalha);
			query.setParameter("dataHora", Calendar.getInstance(), TemporalType.TIMESTAMP);

			query.executeUpdate();
			this.logger.info("AS002 - Registro de autorização " + codigoAutorizacao
					+ " invalidado por falha de comunicação com o ECM.");

		} catch (RuntimeException re) {
			this.logger.info(
					"AS.RE.002 - Falha ao tentar invalidar o registro de autorização por falha na comunicação com o ECM.");
			throw new AutorizacaoException("invalidaPorFalhaECM: " + re.getMessage(), re.getCause());
		}
	}

	public boolean updateInformeNegocio(Long codigoAutorizacao, String protocoloNegocio) {
		try {
			StringBuilder jpql = new StringBuilder();
			jpql.append(
					"UPDATE Autorizacao SET dataHoraInformeNagocio = :dataHora, protocoloNegocio = :protocoloNegocio WHERE codigoNSU = :codigoNSU ");

			Query query = this.entityManager.createQuery(jpql.toString());
			query.setParameter("codigoNSU", codigoAutorizacao);
			query.setParameter("protocoloNegocio", protocoloNegocio);
			query.setParameter("dataHora", Calendar.getInstance(), TemporalType.TIMESTAMP);

			int registrosAlterados = this.entityManager.createQuery(jpql.toString()).executeUpdate();
			return registrosAlterados > 0 ? true : false;
		} catch (RuntimeException re) {
			this.logger.info(
					"AS.RE.003 - Falha ao tentar atualizar o registro de autorização por comunicação com sistema de Negocio.");
			throw new AutorizacaoException("updateInformeNegocio: " + re.getMessage(), re.getCause());
		}
	}

	/**
	 * Metodo responsavel por gerar a quantidade de autorizações concedidas
	 * consolidads por produto e por mês considerando os ultimos 12 meses;
	 * 
	 * @return Retorna um Map em que a chave é o nome do produto e o valor é um
	 *         segundo map tendo agora como chave o periodo e como valor a
	 *         quantidade de autorizações concedidas;<br>
	 *         Ex: {CONTA CORRENTE PF={09/2017=19, 10/2017=12, 11/2017=25},
	 *         CONSIGNADO={11/2017=3}}
	 */
	public Map<String, Map<String, Long>> getQuantidadeAutorizacoesMensais() {

		Map<String, Map<String, Long>> resumoAutorizacoes = new HashMap<String, Map<String, Long>>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
		Calendar dataBusca = Calendar.getInstance();
		dataBusca.add(Calendar.MONTH, -12);
		dataBusca.set(Calendar.DAY_OF_MONTH, 1);

		StringBuilder jpql = new StringBuilder();
		jpql.append(" SELECT ");
		jpql.append("     COUNT(nu_autorizacao),");
		jpql.append("     extract(month from ts_registro) || '/' || extract(year from ts_registro) as dt_autorizacao,");
		jpql.append("     no_produto");
		jpql.append(" FROM dostb100_autorizacao");
		jpql.append(" WHERE ts_registro BETWEEN '").append(dateFormat.format(dataBusca.getTime()))
				.append("' AND now()");
		jpql.append(" GROUP BY dt_autorizacao, no_produto");
		jpql.append(" ORDER BY no_produto, dt_autorizacao");

		Query query = this.entityManager.createNativeQuery(jpql.toString());

		List<?> retorno = query.getResultList();
		for (Object registro : retorno) {
			Object[] reg = (Object[]) registro;
			Long quantidade = ((BigInteger) reg[0]).longValue();
			String data = (String) reg[1];
			String produto = (String) reg[2];

			Map<String, Long> resumoQuantidade = resumoAutorizacoes.get(produto);
			if (resumoQuantidade == null) {
				resumoQuantidade = new HashMap<String, Long>();
			}
			resumoQuantidade.put(data, quantidade);

			resumoAutorizacoes.put(produto, resumoQuantidade);
		}

		return resumoAutorizacoes;
	}

	@Override
	protected EntityManager getEntityManager() {
		return this.entityManager;
	}

	private Autorizacao createAutorizacao(String codigoClienteGED, Produto produto,
			List<ECMDocumentoLocalizadoDTO> documentosUtilizados, String sistemaSolicitante) {
		try {
			logger.info("***** Metodo AutorizacaoService.createAutorizacao executado *****");

			Autorizacao autorizacao = new Autorizacao();
			autorizacao.setCodigoClienteGED(codigoClienteGED);
			autorizacao.setCodigoSistemaSolicitante(sistemaSolicitante);
			autorizacao.setCodigoNSU(this.createNSUAutorizacao());
			autorizacao.setDataHoraRegistro(Calendar.getInstance());
			autorizacao.setProdutoOperacao(produto.getOperacao());
			autorizacao.setProdutoModalidade(produto.getModalidade());
			autorizacao.setProdutoNome(produto.getNome());
			for (ECMDocumentoLocalizadoDTO documentoLocalizadoDTO : documentosUtilizados) {
				DocumentoAutorizacao documentoAutorizacao = new DocumentoAutorizacao();
				documentoAutorizacao.setAutorizacao(autorizacao);
				documentoAutorizacao.setCodigoGED(documentoLocalizadoDTO.getAtributosDocumento().getId());
				autorizacao.addDocumentosAutorizacao(documentoAutorizacao);
			}

			this.save(autorizacao);
			return autorizacao;
		} catch (RuntimeException re) {
			this.logger.info("AS.RE.004 - Falha ao criar o objeto de autorização por falha na comunicação com o ECM.");
			throw new AutorizacaoException("createAutorizacao: " + re.getMessage(), re.getCause());
		}
	}

	private Long createNSUAutorizacao() {
		return Calendar.getInstance().getTimeInMillis() * Thread.currentThread().getId();
	}

}
